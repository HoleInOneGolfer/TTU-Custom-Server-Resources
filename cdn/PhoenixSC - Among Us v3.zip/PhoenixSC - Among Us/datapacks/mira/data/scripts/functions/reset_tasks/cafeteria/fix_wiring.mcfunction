fill 751 3 1437 757 3 1437 air
execute if score stage game_track matches 0 run function scripts:randomisers/5
execute if score var1 var matches 0 run clone 720 7 1408 720 7 1408 756 2 1439
execute if score var1 var matches 1 run clone 721 7 1408 721 7 1408 756 2 1439
execute if score var1 var matches 2 run clone 722 7 1408 722 7 1408 756 2 1439
execute if score var1 var matches 3 run clone 723 7 1408 723 7 1408 756 2 1439
execute if score var1 var matches 4 run clone 724 7 1408 724 7 1408 756 2 1439
clear @a[x=751,y=2,z=1439,dx=6,dy=3,dz=1]