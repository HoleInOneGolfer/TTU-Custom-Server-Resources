execute as @a[x=721,y=2,z=1406,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=721,y=2,z=1406,dx=6,dy=3,dz=1] @e[tag=locker_room,tag=fix_wiring,limit=1]

execute as @e[tag=locker_room,tag=fix_wiring,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/locker_room/fix_wiring