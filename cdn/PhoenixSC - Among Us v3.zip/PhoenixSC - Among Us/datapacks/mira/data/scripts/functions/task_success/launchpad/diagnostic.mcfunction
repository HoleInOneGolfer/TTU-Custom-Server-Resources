execute as @a at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 2.0

execute as @e[tag=launchpad,tag=diagnostic,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/launchpad/diagnostic