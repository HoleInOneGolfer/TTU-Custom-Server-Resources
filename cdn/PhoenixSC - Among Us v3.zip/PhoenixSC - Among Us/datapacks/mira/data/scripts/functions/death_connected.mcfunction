summon minecraft:armor_stand ~ ~ ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["body"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:4}}]}


execute if entity @s[tag=launchpad,tag=fuel] run execute as @a[tag=!ghost,tag=crewmate,x=701,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=launchpad,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=711,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=locker_room,tag=fix_wiring] run execute as @a[tag=!ghost,tag=crewmate,x=721,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=reactor,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=731,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=reactor,tag=unlock_manifolds] run execute as @a[tag=!ghost,tag=crewmate,x=741,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=reactor,tag=start_reactor] run execute as @a[tag=!ghost,tag=crewmate,x=751,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=laboratory,tag=fix_wiring] run execute as @a[tag=!ghost,tag=crewmate,x=761,y=2,z=1406,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=laboratory,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=701,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=laboratory,tag=assemble] run execute as @a[tag=!ghost,tag=crewmate,x=711,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=laboratory,tag=sort_samples] run execute as @a[tag=!ghost,tag=crewmate,x=721,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=med_bay,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=731,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=communications,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=741,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=communications,tag=fix_wiring] run execute as @a[tag=!ghost,tag=crewmate,x=751,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=office,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=761,y=2,z=1417,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=office,tag=process_data] run execute as @a[tag=!ghost,tag=crewmate,x=701,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=greenhouse,tag=fix_wiring] run execute as @a[tag=!ghost,tag=crewmate,x=711,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=greenhouse,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=721,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=greenhouse,tag=clean] run execute as @a[tag=!ghost,tag=crewmate,x=731,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=greenhouse,tag=water_plants] run execute as @a[tag=!ghost,tag=crewmate,x=741,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=admin,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=751,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=admin,tag=chart] run execute as @a[tag=!ghost,tag=crewmate,x=761,y=2,z=1428,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=admin,tag=enter_id] run execute as @a[tag=!ghost,tag=crewmate,x=701,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=admin,tag=prime_shields] run execute as @a[tag=!ghost,tag=crewmate,x=711,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=cafeteria,tag=divert_power] run execute as @a[tag=!ghost,tag=crewmate,x=721,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=cafeteria,tag=empty_garbage] run execute as @a[tag=!ghost,tag=crewmate,x=731,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=cafeteria,tag=buy_beverage] run execute as @a[tag=!ghost,tag=crewmate,x=741,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=cafeteria,tag=fix_wiring] run execute as @a[tag=!ghost,tag=crewmate,x=751,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=storage,tag=water_plants] run execute as @a[tag=!ghost,tag=crewmate,x=761,y=2,z=1439,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=balcony,tag=clear_asteroids] run execute as @a[tag=!ghost,tag=crewmate,x=701,y=2,z=1450,dx=6,dy=3,dz=1] run function scripts:death_anim
execute if entity @s[tag=balcony,tag=measure_weather] run execute as @a[tag=!ghost,tag=crewmate,x=711,y=2,z=1450,dx=6,dy=3,dz=1] run function scripts:death_anim


