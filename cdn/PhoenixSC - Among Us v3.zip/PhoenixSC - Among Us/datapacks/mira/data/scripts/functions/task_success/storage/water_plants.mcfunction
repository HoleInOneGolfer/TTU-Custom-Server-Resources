execute as @a[x=761,y=2,z=1439,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=761,y=2,z=1439,dx=6,dy=3,dz=1] water_bucket
clear @a[x=761,y=2,z=1439,dx=6,dy=3,dz=1] bucket

tp @a[x=761,y=2,z=1439,dx=6,dy=3,dz=1] @e[tag=storage,tag=water_plants,limit=1]

execute as @e[tag=storage,tag=water_plants,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/storage/water_plants

execute as @e[tag=task,tag=part2,tag=!incomplete,tag=water_plants,limit=1,sort=random] run function scripts:increment_task
