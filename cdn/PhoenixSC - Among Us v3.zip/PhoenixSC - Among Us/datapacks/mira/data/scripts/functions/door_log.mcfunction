#execute if score comms sabotage matches 0.. run playsound minecraft:comms_down master @p
#execute if score comms sabotage matches 0.. run tellraw @p ["",{"text":"\n"},{"text":" Comms are down"},{"text":"\n"}]



execute if score comms sabotage matches -1 run tellraw @p {"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"}
#execute if score comms sabotage matches -1 run execute as @p at @s run playsound minecraft:generic master @s
execute if score comms sabotage matches -1 run tellraw @p {"text":""}
execute if score comms sabotage matches -1 run tellraw @p {"text":"\n /doorLogMIRA.exe","bold":"true","color":"dark_purple","italic":"true"}
execute if score comms sabotage matches -1 run tellraw @p {"text":" -----------------------------","color":"gray"}


execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=20}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=19}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=18}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=17}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=16}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=15}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=14}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=13}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=12}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=11}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=10}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=9}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=8}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=7}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=6}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=5}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=4}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=3}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=2}] run function scripts:door_log_send
execute if score comms sabotage matches -1 run execute as @e[scores={door_log_id=1}] run function scripts:door_log_send


execute if score comms sabotage matches -1 run tellraw @p {"text":""}