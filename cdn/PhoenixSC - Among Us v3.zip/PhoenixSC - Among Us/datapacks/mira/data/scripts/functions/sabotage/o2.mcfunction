scoreboard players set o2 sabotage 880
scoreboard players set cd sabotage 2000000
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage O2","italic":"false"}'},HideFlags:63,CustomModelData:9}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Reactor","italic":"false"}'},HideFlags:63,CustomModelData:10}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Comms","italic":"false"}'},HideFlags:63,CustomModelData:11}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Lights","italic":"false"}'},HideFlags:63,CustomModelData:12}
execute as @a at @s run playsound minecraft:meltdown master @s ~ ~ ~ 9999

execute as @e[tag=o2_sabotage,limit=4] at @s run setblock ~ ~ ~ lever[face=wall,facing=east,powered=false]