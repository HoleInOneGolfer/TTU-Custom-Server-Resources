execute as @a[x=731,y=2,z=1417,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=731,y=2,z=1417,dx=6,dy=3,dz=1] @e[tag=med_bay,tag=divert_power,limit=1]

execute as @e[tag=med_bay,tag=divert_power,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/med_bay/divert_power
