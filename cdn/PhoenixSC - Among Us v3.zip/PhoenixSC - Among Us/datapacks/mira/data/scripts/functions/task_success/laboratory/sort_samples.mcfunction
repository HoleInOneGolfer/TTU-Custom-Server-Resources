execute as @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] diamond
clear @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] blaze_rod
clear @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] jungle_leaves
clear @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] bone

tp @a[x=721,y=2,z=1417,dx=6,dy=3,dz=1] @e[tag=laboratory,tag=sort_samples,limit=1]

execute as @e[tag=laboratory,tag=sort_samples,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/sort_samples

