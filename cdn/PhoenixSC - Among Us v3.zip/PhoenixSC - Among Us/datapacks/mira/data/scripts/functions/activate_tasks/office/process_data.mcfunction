## Crewmate
execute if entity @s[tag=crewmate] run tp @s 704 2 1429 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked