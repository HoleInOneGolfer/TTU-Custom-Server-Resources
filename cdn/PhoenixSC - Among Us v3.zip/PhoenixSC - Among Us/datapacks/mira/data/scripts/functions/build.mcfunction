time set 6000

scoreboard objectives add click minecraft.used:minecraft.carrot_on_a_stick
kill @e[tag=task]
kill @e[tag=camera]
kill @e[tag=camera_marker]
kill @e[tag=SKIP_detect]
kill @e[tag=vent]
kill @e[tag=decon_door]
kill @e[tag=sensor]
kill @e[tag=door_log]
kill @e[tag=o2_sabotage]
kill @e[tag=door]
kill @e[tag=model]
kill @e[tag=alert]
team add playing
team modify playing nametagVisibility never
team modify playing seeFriendlyInvisibles false
team modify playing collisionRule never
team add ghost
team modify ghost nametagVisibility never
team modify ghost seeFriendlyInvisibles true
team modify ghost collisionRule never
team add alert
team modify alert color red
gamemode adventure @a
kill @e[tag=launchpad_spawn]
kill @e[tag=cafeteria_spawn]
kill @e[tag=camera_model]
execute as @e[type=item_frame] run data merge entity @s {Invisible:1b,Fixed:1b}
execute as @e[type=painting] run data merge entity @s {Invulnerable:1b}
execute as @e[type=armor_stand] run data merge entity @s {DisabledSlots:4144959}
gamerule sendCommandFeedback false
gamerule announceAdvancements false


## Task-markers
# Launchpad
summon minecraft:armor_stand 729 161 1418 {CustomName:'{"text":"Launchpad"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fuel","launchpad"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 729 161 1420 {CustomName:'{"text":"Launchpad"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","launchpad"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 739 161 1418 {CustomName:'{"text":"Launchpad"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","diagnostic","launchpad"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Locker Room
summon minecraft:armor_stand 753 161 1418 {CustomName:'{"text":"Locker Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","locker_room"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Reactor
summon minecraft:armor_stand 746 161 1399 {CustomName:'{"text":"Reactor"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","divert_power","reactor"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 745 161 1396 {CustomName:'{"text":"Reactor"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","unlock_manifolds","reactor"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 749 161 1396 {CustomName:'{"text":"Reactor"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","start_reactor","reactor"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Laboratory
summon minecraft:armor_stand 757 161 1392 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 760 161 1392 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 765 161 1393 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","assemble","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 764 161 1400 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","sort_samples","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Med Bay
summon minecraft:armor_stand 776 161 1419 {CustomName:'{"text":"Med Bay"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","med_bay"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 779 162 1423 {CustomName:'{"text":"Med Bay"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","submit_scan","med_bay"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}

# Communications
summon minecraft:armor_stand 774 161 1412 {CustomName:'{"text":"Communications"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","communications"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 769 161 1406 {CustomName:'{"text":"Communications (Hallway)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","communications"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Office
summon minecraft:armor_stand 777 161 1383 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 778 161 1380 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","process_data","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Greenhouse
summon minecraft:armor_stand 780 161 1380 {CustomName:'{"text":"Greenhouse"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","greenhouse"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 773 161 1375 {CustomName:'{"text":"Greenhouse"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","greenhouse"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 780 161 1374 {CustomName:'{"text":"Greenhouse"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","clean","greenhouse"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 789 161 1376 {CustomName:'{"text":"Greenhouse"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","water_plants","greenhouse"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Admin
summon minecraft:armor_stand 788 161 1380 {CustomName:'{"text":"Admin"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","admin"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 790 161 1381 {CustomName:'{"text":"Admin"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","chart","admin"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 786 161 1385 {CustomName:'{"text":"Admin"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","enter_id","admin"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 789 161 1389 {CustomName:'{"text":"Admin"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","prime_shields","admin"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Cafeteria
summon minecraft:armor_stand 790 161 1411 {CustomName:'{"text":"Cafeteria"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","divert_power","cafeteria"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 797 161 1411 {CustomName:'{"text":"Cafeteria"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","empty_garbage","cafeteria"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 801 161 1412 {CustomName:'{"text":"Cafeteria"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","buy_beverage","cafeteria"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 783 161 1421 {CustomName:'{"text":"Cafeteria"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","cafeteria"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Storage
summon minecraft:armor_stand 785 161 1412 {CustomName:'{"text":"Storage"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","water_plants","storage"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Balcony
summon minecraft:armor_stand 786 161 1427 {CustomName:'{"text":"Balcony"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","clear_asteroids","balcony"],DisabledSlots:4144959,Rotation:[0f],CustomNameVisible:0b}
summon minecraft:armor_stand 803 161 1426 {CustomName:'{"text":"Balcony"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","measure_weather","balcony"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}


## SKIP
summon minecraft:armor_stand 0 64 0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["SKIP_detect","SKIP"],DisabledSlots:4144959,CustomName:'{"text":"SKIP"}',CustomNameVisible:0b}

## Vent-markers
summon minecraft:armor_stand 730 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v1"],DisabledSlots:4144959,Rotation:[-47f]}
summon minecraft:armor_stand 753 161 1422 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v2"],DisabledSlots:4144959,Rotation:[-123f]}
summon minecraft:armor_stand 777 161 1427 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v3"],DisabledSlots:4144959,Rotation:[174f]}
summon minecraft:armor_stand 794 161 1427 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v4"],DisabledSlots:4144959,Rotation:[134f]}
summon minecraft:armor_stand 758 161 1415 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v5"],DisabledSlots:4144959,Rotation:[175f]}
summon minecraft:armor_stand 745 161 1401 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v6"],DisabledSlots:4144959,Rotation:[-125f]}
summon minecraft:armor_stand 769 161 1394 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v7"],DisabledSlots:4144959,Rotation:[50f]}
summon minecraft:armor_stand 793 161 1406 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v8"],DisabledSlots:4144959,Rotation:[45f]}
summon minecraft:armor_stand 771 161 1383 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v9"],DisabledSlots:4144959,Rotation:[-78f]}
summon minecraft:armor_stand 792 161 1390 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v10"],DisabledSlots:4144959,Rotation:[143f]}
summon minecraft:armor_stand 781 161 1368 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v11"],DisabledSlots:4144959,Rotation:[0f]}


## Faking
scoreboard objectives add faked dummy
scoreboard objectives add being_faked dummy
scoreboard players set @e[tag=task] faked 0
scoreboard players set @e[tag=task] being_faked 0

## O2 sabotage markers
summon minecraft:armor_stand 784 161 1373 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["o2_sabotage","o2_sabotage1"],DisabledSlots:4144959}
summon minecraft:armor_stand 784 161 1372 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["o2_sabotage","o2_sabotage2"],DisabledSlots:4144959}
summon minecraft:armor_stand 784 161 1371 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["o2_sabotage","o2_sabotage3"],DisabledSlots:4144959}
summon minecraft:armor_stand 784 161 1370 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["o2_sabotage","o2_sabotage4"],DisabledSlots:4144959}

execute as @e[tag=o2_sabotage] at @s run setblock ~ ~ ~ air
#execute as @e[tag=o2_sabotage] at @s run setblock ~ ~ ~ lever[face=wall,facing=south,powered=true]

## Lights
fill 773 163 1380 776 163 1380 lever[face=wall,facing=south,powered=true]
fill 773 162 1379 776 162 1379 minecraft:redstone_lamp[lit=true]

## Doors/location
scoreboard objectives add location dummy
scoreboard players set @a location 0

## Admin map
summon minecraft:armor_stand 789.5 162 1384.85 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","map_mira"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:56}}],Rotation:[0f]}

## Sabotage alerts
summon minecraft:armor_stand 752 162 1424.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","o2_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
summon minecraft:armor_stand 783 161 1374.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","o2_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
summon minecraft:armor_stand 754 162 1400.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","reactor_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
summon minecraft:armor_stand 772 162 1380.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","lights_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
summon minecraft:armor_stand 775 162 1411.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","comms_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
summon minecraft:armor_stand 773 162 1386.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","comms_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[180f]}
team join alert @e[tag=alert]

## Launchpad spawn
summon minecraft:armor_stand 739 161 1419 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn0"],DisabledSlots:4144959}
summon minecraft:armor_stand 738 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn2"],DisabledSlots:4144959}
summon minecraft:armor_stand 737 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn4"],DisabledSlots:4144959}
summon minecraft:armor_stand 736 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn6"],DisabledSlots:4144959}
summon minecraft:armor_stand 735 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn8"],DisabledSlots:4144959}
summon minecraft:armor_stand 734 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn1"],DisabledSlots:4144959}
summon minecraft:armor_stand 733 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn3"],DisabledSlots:4144959}
summon minecraft:armor_stand 732 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn5"],DisabledSlots:4144959}
summon minecraft:armor_stand 731 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn7"],DisabledSlots:4144959}
summon minecraft:armor_stand 730 161 1419 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["launchpad_spawn","spawn9"],DisabledSlots:4144959}

## Cafeteria spawn
summon minecraft:armor_stand 790 161 1416 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn0"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn2"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1418 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn4"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1419 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn6"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn8"],DisabledSlots:4144959}
summon minecraft:armor_stand 796 161 1420 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn1"],DisabledSlots:4144959}
summon minecraft:armor_stand 796 161 1419 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn3"],DisabledSlots:4144959}
summon minecraft:armor_stand 796 161 1418 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn5"],DisabledSlots:4144959}
summon minecraft:armor_stand 796 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn7"],DisabledSlots:4144959}
summon minecraft:armor_stand 796 161 1416 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["cafeteria_spawn","spawn9"],DisabledSlots:4144959}
execute as @e[tag=cafeteria_spawn] at @s facing 793 161 1418 run tp @s ~ ~ ~ ~ ~

## Decon
scoreboard objectives add decon dummy
scoreboard players set p1 decon 0
scoreboard players set p2 decon 0

## Decontamination doors
summon minecraft:armor_stand 756 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1"],DisabledSlots:4144959}
summon minecraft:armor_stand 757 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1"],DisabledSlots:4144959}
summon minecraft:armor_stand 758 161 1417 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1"],DisabledSlots:4144959}
summon minecraft:armor_stand 756 161 1403 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2"],DisabledSlots:4144959}
summon minecraft:armor_stand 757 161 1403 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2"],DisabledSlots:4144959}
summon minecraft:armor_stand 758 161 1403 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2"],DisabledSlots:4144959}

execute as @e[tag=decon_door] at @s run fill ~ ~ ~ ~ ~1 ~ blue_ice


## Door Logs
scoreboard objectives add door_log_cd dummy
scoreboard players set @a door_log_cd 0

summon minecraft:armor_stand 773 161 1409 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 773 161 1408 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 773 161 1407 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 773 161 1406 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 773 161 1405 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 773 161 1404 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_sw","sensor"],DisabledSlots:4144959}

summon minecraft:armor_stand 780 161 1389 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_n","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 781 161 1389 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_n","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 782 161 1389 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_n","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 783 161 1389 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_n","sensor"],DisabledSlots:4144959}

summon minecraft:armor_stand 790 161 1408 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_se","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1407 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_se","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1406 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_se","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1405 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_se","sensor"],DisabledSlots:4144959}
summon minecraft:armor_stand 790 161 1404 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["sensor_se","sensor"],DisabledSlots:4144959}


## Deco
summon minecraft:armor_stand 779 162.75 1411 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","log_screen"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:69}}],Rotation:[270f]}
