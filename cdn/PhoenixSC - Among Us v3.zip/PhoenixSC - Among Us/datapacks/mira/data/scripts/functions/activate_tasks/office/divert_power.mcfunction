## Crewmate
execute if entity @s[tag=crewmate] run tp @s 764 2 1418 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked