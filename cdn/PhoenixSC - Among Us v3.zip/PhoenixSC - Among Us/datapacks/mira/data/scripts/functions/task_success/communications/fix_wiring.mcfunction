execute as @a[x=751,y=2,z=1417,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=751,y=2,z=1417,dx=6,dy=3,dz=1] @e[tag=communications,tag=fix_wiring,limit=1]

execute as @e[tag=communications,tag=fix_wiring,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/communications/fix_wiring