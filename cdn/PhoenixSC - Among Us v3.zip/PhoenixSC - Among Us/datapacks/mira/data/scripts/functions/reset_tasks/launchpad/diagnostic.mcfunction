scoreboard players reset diagnostic
setblock 739 162 1418 lever[face=wall,facing=west,powered=false]