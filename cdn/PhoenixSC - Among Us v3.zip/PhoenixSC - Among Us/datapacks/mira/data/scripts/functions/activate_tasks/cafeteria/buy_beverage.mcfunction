## Crewmate
execute if entity @s[tag=crewmate] run tp @s 744 2 1440 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked