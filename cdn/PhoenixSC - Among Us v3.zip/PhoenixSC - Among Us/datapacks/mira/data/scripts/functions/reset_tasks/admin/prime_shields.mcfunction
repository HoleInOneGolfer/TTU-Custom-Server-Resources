fill 711 3 1437 717 5 1437 air replace minecraft:red_concrete
setblock 716 2 1439 air
setblock 716 2 1439 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:red_concrete",Count:10b,tag:{CanPlaceOn:["minecraft:white_concrete"]}}]}
clear @a[x=711,y=2,z=1439,dx=6,dy=3,dz=1]