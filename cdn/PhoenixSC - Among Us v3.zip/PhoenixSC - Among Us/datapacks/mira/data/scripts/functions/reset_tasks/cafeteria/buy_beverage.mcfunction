fill 742 5 1436 743 3 1436 air
fill 745 5 1436 746 3 1436 air

fill 742 5 1436 743 3 1436 chest[facing=south,type=single]
fill 745 5 1436 746 3 1436 chest[facing=south,type=single]

execute if score stage game_track matches 0 run function scripts:randomisers/7
execute if score var2 var matches 0 run clone 744 7 1440 744 7 1440 742 3 1436
execute if score var2 var matches 1 run clone 744 7 1440 744 7 1440 743 4 1436
execute if score var2 var matches 2 run clone 744 7 1440 744 7 1440 742 5 1436
execute if score var2 var matches 3 run clone 744 7 1440 744 7 1440 743 5 1436
execute if score var2 var matches 4 run clone 744 7 1440 744 7 1440 746 3 1436
execute if score var2 var matches 5 run clone 744 7 1440 744 7 1440 745 4 1436
execute if score var2 var matches 6 run clone 744 7 1440 744 7 1440 746 5 1436

clear @a[x=741,y=2,z=1439,dx=6,dy=3,dz=1]