execute as @a[x=741,y=2,z=1428,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=741,y=2,z=1428,dx=6,dy=3,dz=1] bucket
clear @a[x=741,y=2,z=1428,dx=6,dy=3,dz=1] water_bucket
tp @a[x=741,y=2,z=1428,dx=6,dy=3,dz=1] @e[tag=greenhouse,tag=water_plants,limit=1]

execute as @e[tag=greenhouse,tag=water_plants,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/greenhouse/water_plants

