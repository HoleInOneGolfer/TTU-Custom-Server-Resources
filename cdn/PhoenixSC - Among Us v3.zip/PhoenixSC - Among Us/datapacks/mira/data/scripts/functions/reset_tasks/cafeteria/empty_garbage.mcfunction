setblock 737 3 1439 lever[powered=false,face=wall,facing=west]
fill 736 3 1436 732 3 1435 gravel
setblock 733 4 1435 gravel
fill 735 4 1435 735 4 1436 gravel
setblock 735 5 1435 gravel

execute if score stage game_track matches 0 run function scripts:randomisers/5

execute if score var1 var matches 1 run fill 732 3 1436 736 5 1435 sand replace gravel
execute if score var1 var matches 2 run fill 732 3 1436 736 5 1435 red_sand replace gravel
execute if score var1 var matches 3 run fill 732 3 1436 736 5 1435 anvil replace gravel
execute if score var1 var matches 4 run fill 732 3 1436 736 5 1435 light_blue_concrete_powder replace gravel