setblock 754 3 1404 air
setblock 754 3 1404 minecraft:dispenser[facing=south,triggered=false]
clone 750 7 1408 750 7 1408 756 2 1406
clear @a[x=751,y=2,z=1406,dx=6,dy=3,dz=1]