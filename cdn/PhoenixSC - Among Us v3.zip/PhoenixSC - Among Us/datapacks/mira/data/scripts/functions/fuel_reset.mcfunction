replaceitem entity @a[x=701,y=2,z=1406,dx=6,dy=3,dz=1] weapon water_bucket{CanPlaceOn:["minecraft:cauldron"]}
fill 703 3 1404 705 3 1402 air