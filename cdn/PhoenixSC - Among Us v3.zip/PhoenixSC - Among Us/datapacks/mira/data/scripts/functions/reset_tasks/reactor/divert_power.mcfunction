fill 731 3 1402 737 3 1402 redstone_wire
execute if score stage game_track matches 0 run function scripts:randomisers/7

execute if score var2 var matches 0 run setblock 731 3 1402 air
execute if score var2 var matches 1 run setblock 732 3 1402 air
execute if score var2 var matches 2 run setblock 733 3 1402 air
execute if score var2 var matches 3 run setblock 734 3 1403 air
execute if score var2 var matches 4 run setblock 735 3 1402 air
execute if score var2 var matches 5 run setblock 736 3 1402 air
execute if score var2 var matches 6 run setblock 737 3 1402 air