fill 711 3 1426 717 3 1426 air
execute if score stage game_track matches 0 run function scripts:randomisers/5
execute if score var1 var matches 0 run clone 720 7 1408 720 7 1408 716 2 1428
execute if score var1 var matches 1 run clone 721 7 1408 721 7 1408 716 2 1428
execute if score var1 var matches 2 run clone 722 7 1408 722 7 1408 716 2 1428
execute if score var1 var matches 3 run clone 723 7 1408 723 7 1408 716 2 1428
execute if score var1 var matches 4 run clone 724 7 1408 724 7 1408 716 2 1428
clear @a[x=711,y=2,z=1428,dx=6,dy=3,dz=1]