## Launchpad
execute if entity @e[tag=launchpad,tag=fuel,tag=incomplete] if blocks 703 2 1402 705 2 1404 703 7 1403 all run function scripts:task_success/launchpad/fuel
execute if entity @e[tag=launchpad,tag=divert_power,tag=incomplete] if block 718 3 1404 redstone_lamp[lit=true] run function scripts:task_success/launchpad/divert_power
execute if entity @e[tag=launchpad,tag=diagnostic,tag=incomplete] if score diagnostic diagnostic matches 0 run function scripts:task_success/launchpad/diagnostic

## Locker Room
execute if entity @e[tag=locker_room,tag=fix_wiring,tag=incomplete] if block 721 3 1401 minecraft:redstone_lamp[lit=true] if block 723 3 1401 minecraft:redstone_lamp[lit=true] if block 725 3 1401 minecraft:redstone_lamp[lit=true] if block 727 3 1401 minecraft:redstone_lamp[lit=true] run function scripts:task_success/locker_room/fix_wiring

## Reactor
execute if entity @e[tag=reactor,tag=divert_power,tag=incomplete] if block 734 3 1400 minecraft:redstone_lamp[lit=true] run function scripts:task_success/reactor/divert_power
execute if entity @e[tag=reactor,tag=unlock_manifolds,tag=incomplete] if block 742 3 1402 minecraft:redstone_lamp[lit=true] if block 742 3 1404 minecraft:redstone_lamp[lit=true] if block 744 3 1403 minecraft:redstone_lamp[lit=true] if block 746 3 1402 minecraft:redstone_lamp[lit=true] if block 746 3 1404 minecraft:redstone_lamp[lit=true] run function scripts:task_success/reactor/unlock_manifolds
execute if entity @e[tag=reactor,tag=start_reactor,tag=incomplete] if blocks 754 3 1404 754 3 1404 754 7 1404 all run function scripts:task_success/reactor/start_reactor

## Laboratory
execute if entity @e[tag=laboratory,tag=fix_wiring,tag=incomplete] if block 761 3 1401 minecraft:redstone_lamp[lit=true] if block 763 3 1401 minecraft:redstone_lamp[lit=true] if block 765 3 1401 minecraft:redstone_lamp[lit=true] if block 767 3 1401 minecraft:redstone_lamp[lit=true] run function scripts:task_success/laboratory/fix_wiring
execute if entity @e[tag=laboratory,tag=divert_power,tag=incomplete] if block 708 3 1415 redstone_lamp[lit=true] run function scripts:task_success/laboratory/divert_power
execute if entity @e[tag=laboratory,tag=assemble,tag=incomplete] if blocks 712 4 1415 716 4 1415 712 7 1415 all run function scripts:task_success/laboratory/assemble
execute if entity @e[tag=laboratory,tag=sort_samples,tag=incomplete] if blocks 722 3 1413 726 3 1415 722 8 1413 all run function scripts:task_success/laboratory/sort_samples

## Med Bay
execute if entity @e[tag=med_bay,tag=divert_power,tag=incomplete] if block 738 3 1415 redstone_lamp[lit=true] run function scripts:task_success/med_bay/divert_power
execute if entity @e[tag=med_bay,tag=submit_scan,tag=incomplete] if score submit_scan submit_scan matches 0 run function scripts:task_success/med_bay/submit_scan

## Communications
execute if entity @e[tag=communications,tag=divert_power,tag=incomplete] if block 748 3 1415 redstone_lamp[lit=true] run function scripts:task_success/communications/divert_power
execute if entity @e[tag=communications,tag=fix_wiring,tag=incomplete] if block 751 3 1412 minecraft:redstone_lamp[lit=true] if block 753 3 1412 minecraft:redstone_lamp[lit=true] if block 755 3 1412 minecraft:redstone_lamp[lit=true] if block 757 3 1412 minecraft:redstone_lamp[lit=true] run function scripts:task_success/communications/fix_wiring

## Office
execute if entity @e[tag=office,tag=divert_power,tag=incomplete] if block 768 3 1415 redstone_lamp[lit=true] run function scripts:task_success/office/divert_power
execute if entity @e[tag=office,tag=process_data,tag=incomplete] if block 707 4 1426 command_block{powered:1b} run function scripts:task_success/office/process_data

## Greenhouse
execute if entity @e[tag=greenhouse,tag=fix_wiring,tag=incomplete] if block 711 3 1423 minecraft:redstone_lamp[lit=true] if block 713 3 1423 minecraft:redstone_lamp[lit=true] if block 715 3 1423 minecraft:redstone_lamp[lit=true] if block 717 3 1423 minecraft:redstone_lamp[lit=true] run function scripts:task_success/greenhouse/fix_wiring
execute if entity @e[tag=greenhouse,tag=divert_power,tag=incomplete] if block 728 3 1426 redstone_lamp[lit=true] run function scripts:task_success/greenhouse/divert_power
execute if entity @e[tag=greenhouse,tag=clean,tag=incomplete] if blocks 731 3 1427 737 5 1424 731 10 1424 all run function scripts:task_success/greenhouse/clean
execute if entity @e[tag=greenhouse,tag=water_plants,tag=incomplete] if blocks 741 2 1427 747 3 1423 741 10 1423 all run function scripts:task_success/greenhouse/water_plants

## Admin
execute if entity @e[tag=admin,tag=divert_power,tag=incomplete] if block 758 3 1426 redstone_lamp[lit=true] run function scripts:task_success/admin/divert_power
execute if entity @e[tag=admin,tag=chart,tag=incomplete] if block 762 3 1426 redstone_lamp[lit=true] if block 763 4 1426 redstone_lamp[lit=true] if block 764 5 1426 redstone_lamp[lit=true] if block 765 4 1426 redstone_lamp[lit=true] if block 766 5 1426 redstone_lamp[lit=true] run function scripts:task_success/admin/chart
execute if entity @e[tag=admin,tag=enter_id,tag=incomplete] if block 701 4 1437 redstone_lamp[lit=true] if block 702 3 1437 redstone_lamp[lit=true] if block 703 4 1437 redstone_lamp[lit=true] if block 704 5 1437 redstone_lamp[lit=true] if block 705 4 1437 redstone_lamp[lit=true] if block 706 3 1437 redstone_lamp[lit=true] if block 707 4 1437 redstone_lamp[lit=true] run function scripts:task_success/admin/enter_id
execute if entity @e[tag=admin,tag=prime_shields,tag=incomplete] if block 712 5 1437 minecraft:red_concrete if block 714 5 1437 minecraft:red_concrete if block 716 5 1437 minecraft:red_concrete if block 712 3 1437 minecraft:red_concrete if block 714 3 1437 minecraft:red_concrete if block 716 3 1437 minecraft:red_concrete if block 711 4 1437 minecraft:red_concrete if block 713 4 1437 minecraft:red_concrete if block 715 4 1437 minecraft:red_concrete if block 717 4 1437 minecraft:red_concrete run function scripts:task_success/admin/prime_shields

## Cafeteria
execute if entity @e[tag=cafeteria,tag=divert_power,tag=incomplete] if block 728 3 1437 redstone_lamp[lit=true] run function scripts:task_success/cafeteria/divert_power
execute if entity @e[tag=cafeteria,tag=empty_garbage,tag=incomplete] if blocks 732 2 1436 736 5 1435 732 7 1436 all run function scripts:task_success/cafeteria/empty_garbage
execute if entity @e[tag=cafeteria,tag=buy_beverage,tag=incomplete] if blocks 742 3 1436 746 5 1436 742 8 1436 all run function scripts:task_success/cafeteria/buy_beverage
execute if entity @e[tag=cafeteria,tag=fix_wiring,tag=incomplete] if block 751 3 1434 minecraft:redstone_lamp[lit=true] if block 753 3 1434 minecraft:redstone_lamp[lit=true] if block 755 3 1434 minecraft:redstone_lamp[lit=true] if block 757 3 1434 minecraft:redstone_lamp[lit=true] run function scripts:task_success/cafeteria/fix_wiring

## Storage
execute if entity @e[tag=storage,tag=water_plants,tag=incomplete] if blocks 762 3 1436 766 5 1436 762 8 1436 all run function scripts:task_success/storage/water_plants

## Balcony
execute if entity @e[tag=balcony,tag=clear_asteroids,tag=incomplete] if blocks 701 3 1449 707 5 1446 701 10 1446 all run function scripts:task_success/balcony/clear_asteroids
execute if entity @e[tag=balcony,tag=measure_weather,tag=incomplete] if block 717 4 1448 command_block{powered:1b} run function scripts:task_success/balcony/measure_weather

