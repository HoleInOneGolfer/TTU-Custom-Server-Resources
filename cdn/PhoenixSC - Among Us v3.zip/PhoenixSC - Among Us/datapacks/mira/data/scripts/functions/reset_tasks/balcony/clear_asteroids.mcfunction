clone 701 7 1449 707 9 1446 701 3 1446
setblock 707 2 1451 air
setblock 707 2 1451 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:netherite_pickaxe",Count:1b,tag:{CanDestroy:["minecraft:cobblestone"],Unbreakable:1b}}]}
clear @a[x=701,y=2,z=1450,dx=6,dy=3,dz=1]