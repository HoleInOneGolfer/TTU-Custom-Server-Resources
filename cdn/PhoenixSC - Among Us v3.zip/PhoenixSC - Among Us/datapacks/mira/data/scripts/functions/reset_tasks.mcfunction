kill @e[type=item]

## Launchpad
function scripts:reset_tasks/launchpad/fuel
function scripts:reset_tasks/launchpad/divert_power
function scripts:reset_tasks/launchpad/diagnostic

## Locker Room
function scripts:reset_tasks/locker_room/fix_wiring

## Reactor
function scripts:reset_tasks/reactor/divert_power
function scripts:reset_tasks/reactor/unlock_manifolds
function scripts:reset_tasks/reactor/start_reactor

# Laboratory
function scripts:reset_tasks/laboratory/fix_wiring
function scripts:reset_tasks/laboratory/divert_power
function scripts:reset_tasks/laboratory/assemble
function scripts:reset_tasks/laboratory/sort_samples

# Med Bay
function scripts:reset_tasks/med_bay/divert_power
function scripts:reset_tasks/med_bay/submit_scan

# Communications
function scripts:reset_tasks/communications/divert_power
function scripts:reset_tasks/communications/fix_wiring

# Office
function scripts:reset_tasks/office/divert_power
function scripts:reset_tasks/office/process_data

# Greenhouse
function scripts:reset_tasks/greenhouse/fix_wiring
function scripts:reset_tasks/greenhouse/divert_power
function scripts:reset_tasks/greenhouse/clean
function scripts:reset_tasks/greenhouse/water_plants

# Admin
function scripts:reset_tasks/admin/divert_power
function scripts:reset_tasks/admin/chart
function scripts:reset_tasks/admin/enter_id
function scripts:reset_tasks/admin/prime_shields

# Cafeteria
function scripts:reset_tasks/cafeteria/divert_power
function scripts:reset_tasks/cafeteria/empty_garbage
function scripts:reset_tasks/cafeteria/buy_beverage
function scripts:reset_tasks/cafeteria/fix_wiring

# Storage
function scripts:reset_tasks/storage/water_plants

# Balcony
function scripts:reset_tasks/balcony/clear_asteroids
function scripts:reset_tasks/balcony/measure_weather

## SABOTAGE MISSIONS TO BE DONE IN-GAME

