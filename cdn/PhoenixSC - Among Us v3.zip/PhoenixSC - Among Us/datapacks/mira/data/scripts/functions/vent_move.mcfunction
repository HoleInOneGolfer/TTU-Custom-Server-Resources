scoreboard players add @s vent_number 1
execute as @s at @s run playsound minecraft:generic master @s ~ ~ ~ 9999

## Limits
execute as @s[tag=vent_system1] if score @s vent_number matches 12.. run scoreboard players set @s vent_number 1
