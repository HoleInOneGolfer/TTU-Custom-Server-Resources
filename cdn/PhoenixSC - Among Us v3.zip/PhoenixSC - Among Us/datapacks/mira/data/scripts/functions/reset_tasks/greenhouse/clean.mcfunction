clone 731 7 1427 737 9 1424 731 3 1424
setblock 737 2 1429 air
setblock 737 2 1429 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:iron_shovel",Count:1b,tag:{CanDestroy:["minecraft:jungle_leaves"],Unbreakable:1b}}]}
clear @a[x=731,y=2,z=1428,dx=6,dy=3,dz=1]