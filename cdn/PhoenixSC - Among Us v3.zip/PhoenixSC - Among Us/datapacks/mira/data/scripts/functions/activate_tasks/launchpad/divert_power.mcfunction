## Crewmate
execute if entity @s[tag=crewmate] run tp @s 714 2 1407 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked