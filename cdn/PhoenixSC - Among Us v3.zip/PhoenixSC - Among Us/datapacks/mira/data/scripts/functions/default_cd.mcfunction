scoreboard players set @a[tag=impostor] kill_cd 340
execute unless score cd sabotage matches 1000000.. run scoreboard players set cd sabotage 260
scoreboard players set cd_doors sabotage 260