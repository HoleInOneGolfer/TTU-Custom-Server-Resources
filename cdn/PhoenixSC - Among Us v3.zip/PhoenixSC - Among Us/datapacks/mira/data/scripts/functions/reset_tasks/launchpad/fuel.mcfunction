fill 703 2 1404 705 2 1402 cauldron[level=0]
clone 700 7 1408 700 7 1408 706 2 1406
clear @a[x=701,y=2,z=1406,dx=6,dy=3,dz=1]