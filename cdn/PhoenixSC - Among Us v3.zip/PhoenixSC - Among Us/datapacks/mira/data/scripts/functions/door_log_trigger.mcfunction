scoreboard players set @s door_log_cd 50
scoreboard objectives add door_log_id dummy
scoreboard objectives add door_log_player dummy

## SW
execute if entity @e[tag=sensor_sw,distance=..0.5] run summon minecraft:armor_stand 780 162 1411 {CustomName:'{"text":"Southwest sensor","color":"gold"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door_log_new"],DisabledSlots:4144959}
execute if entity @e[tag=sensor_sw,distance=..0.5] as @e[tag=sensor_sw] at @s run particle dust -1 1 0 1 ~ ~ ~ 0.0 0.0 0.0 1.0 10 force

## N
execute if entity @e[tag=sensor_n,distance=..0.5] run summon minecraft:armor_stand 780 162 1411 {CustomName:'{"text":"North sensor","color":"blue"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door_log_new"],DisabledSlots:4144959}
execute if entity @e[tag=sensor_n,distance=..0.5] as @e[tag=sensor_n] at @s run particle dust -1 0.8 1 1 ~ ~ ~ 0.0 0.0 0.0 1.0 10 force

## SE
execute if entity @e[tag=sensor_se,distance=..0.5] run summon minecraft:armor_stand 780 162 1411 {CustomName:'{"text":"Southeast sensor","color":"green"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door_log_new"],DisabledSlots:4144959}
execute if entity @e[tag=sensor_se,distance=..0.5] as @e[tag=sensor_se] at @s run particle dust 1 1 0 1 ~ ~ ~ 0.0 0.0 0.0 1.0 10 force

scoreboard players operation @e[tag=door_log_new] door_log_player = @s player_id
tag @e[tag=door_log_new] add door_log
tag @e[tag=door_log_new] remove door_log_new
scoreboard players add @e[tag=door_log] door_log_id 1
kill @e[scores={door_log_id=21}]