##### IMPORTS #####
#/summon minecraft:armor_stand ~ ~ ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:0}}]}
tp @a[tag=!spawned] -231 1 5
tag @a add spawned
#effect give @a night_vision 9999 0 true
effect give @a jump_boost 9999 128 true
effect give @a resistance 9999 128 true
effect give @a instant_health 9999 128 true
effect give @a weakness 9999 128 true
effect give @a[team=playing] speed 2 0 true
scoreboard objectives add settings dummy {"text":"Custom Settings"}
function scripts:settings
setworldspawn -231 1 5
forceload add 0 0
forceload add 659 1381 804 1484
execute as @e[type=item] run data merge entity @s {PickupDelay:0s}
execute as @e[type=item] at @s run tp @s @p
function scripts:inventory
function scripts:click
scoreboard objectives add var dummy
scoreboard players set ticks_per_sec var 20
#weather rain
scoreboard objectives add food food
effect give @a[scores={food=2..}] minecraft:hunger 1 127 true
effect give @a[scores={food=..3}] minecraft:saturation 1 1 true
#stopsound @a player minecraft:entity.player.big_fall
effect give @e[tag=seat_pig] invisibility 9999 0 true
function scripts:off_seat
execute as @a at @s if block ~ ~ ~ iron_trapdoor[open=false] run function scripts:vent_failsafe


##### MAIN #####
## Game tracking
function scripts:game_track

## Reveal impostors
title @a[tag=impostor] actionbar ["",{"text":"Impostors: ","color":"white","bold":"true"},{"selector":"@a[tag=impostor]","color":"red"}]

## Locations
execute as @a[team=playing] at @s unless block ~ ~-1 ~ netherite_block run function scripts:location
execute as @a[team=ghost] at @s unless block ~ ~-1 ~ netherite_block run function scripts:location

## Particles to reveal tasks
execute as @e[tag=incomplete,tag=!diagnostic,scores={being_faked=0}] at @s if entity @a[distance=..4] run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0
execute unless score diagnostic diagnostic matches 0.. as @e[tag=incomplete,tag=launchpad,tag=diagnostic] at @s if entity @a[distance=..4] run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0

execute unless score diagnostic diagnostic matches 1.. run fill 729 167 1414 738 165 1414 stone
execute if score diagnostic diagnostic matches 1.. run fill 729 167 1414 738 165 1414 redstone_block



## TASKS
# Fuel bucket-miss check
execute if block 703 3 1402 water run function scripts:fuel_reset
execute if block 704 3 1402 water run function scripts:fuel_reset
execute if block 705 3 1402 water run function scripts:fuel_reset
execute if block 703 3 1403 water run function scripts:fuel_reset
execute if block 704 3 1403 water run function scripts:fuel_reset
execute if block 705 3 1403 water run function scripts:fuel_reset
execute if block 703 3 1404 water run function scripts:fuel_reset
execute if block 704 3 1404 water run function scripts:fuel_reset
execute if block 705 3 1404 water run function scripts:fuel_reset

# Cafeteria, empty_garbage
execute if block 737 3 1439 lever[powered=false] run fill 732 1 1436 736 2 1435 iron_block
execute if block 737 3 1439 lever[powered=true] run fill 732 1 1436 736 2 1435 air

# Med Bay
execute unless entity @e[tag=in_meeting] if score diagnostic diagnostic matches 1.. if block 739 162 1418 air run scoreboard players remove diagnostic diagnostic 1
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=med_bay] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.0 0.0 0.0 1.0 10 force
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=med_bay] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run particle minecraft:reverse_portal ~ ~ ~ 0.0 0.0 0.0 1.0 10 force
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=med_bay] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run effect give @s nausea 3 10 true
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=med_bay] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run scoreboard players remove submit_scan submit_scan 1
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=med_bay] unless entity @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] run function scripts:submit_scan_check

## Check if task is occupied
function scripts:task_occupied
function scripts:connect_bodies

## Check task success
function scripts:task_success


## Emergency Meeting cooldown
execute if score e_meeting_cd game_track matches 1.. run scoreboard players remove e_meeting_cd game_track 1

## Check meeting
execute if score e_meetings game_track < EmergencyMeetings settings if score e_meeting_cd game_track matches 0 if score o2 sabotage matches -1 if score reactor sabotage matches -1 if score comms sabotage matches -1 if score lights sabotage matches -1 unless entity @e[tag=report_body] run particle dust -1 1 0 0.5 793 162.5 1418 0.0 0.0 0.0 1.0 10 force
execute if entity @e[tag=SKIP,tag=eject] run function scripts:meeting/result_skipped
execute if entity @e[tag=!SKIP,tag=eject] run function scripts:meeting/result_ejected

## Kill cooldown
execute as @a[tag=impostor,tag=!venting,tag=!surveil] if score @s kill_cd matches 1.. run scoreboard players remove @s kill_cd 1

## Clear blur
execute as @a[tag=crewmate] if score @s clear_blur matches 1.. run scoreboard players remove @s clear_blur 1
execute as @a[tag=crewmate] if score @s clear_blur matches 0 run replaceitem entity @s armor.head air

## Ghost movement
function scripts:ghost

## Vent TP
effect give @a[tag=venting] invisibility 2 0 true
function scripts:venting_system

## Fake mechanic
scoreboard players remove @e[scores={faked=1..}] faked 1
scoreboard players set @e[scores={faked=1}] being_faked 600
scoreboard players remove @e[scores={being_faked=1..}] being_faked 1

## Comms down
execute if score comms sabotage matches 0.. run title @a[tag=surveil] title {"text":""}
execute if score comms sabotage matches 0.. run title @a[tag=surveil] subtitle {"text":"Comms are down"}
execute if score comms sabotage matches 0.. run effect clear @a[tag=surveil] invisibility


## Sabotage cooldown
execute if score cd sabotage matches 1.. unless entity @a[tag=impostor,tag=venting] unless entity @a[tag=impostor,tag=surveil] run scoreboard players remove cd sabotage 1

## Sabotage displays
execute if score o2 sabotage matches -1 if score reactor sabotage matches -1 run worldborder warning distance 0

execute if score o2 sabotage matches 0.. run function scripts:sabotage_display_o2
execute if score o2 sabotage matches 0.. run execute store result bossbar minecraft:o2 value run scoreboard players get o2 sabotage
execute if score o2 sabotage matches -1 run bossbar set minecraft:o2 players
execute if score o2 sabotage matches 0..200 run worldborder warning distance 2000000000
function scripts:o2_fix

execute if score reactor sabotage matches 0.. run function scripts:sabotage_display_reactor
execute if score reactor sabotage matches 0.. run execute store result bossbar minecraft:reactor value run scoreboard players get reactor sabotage
execute if score reactor sabotage matches -1 run bossbar set minecraft:reactor players
execute if score reactor sabotage matches 0..200 run worldborder warning distance 2000000000
function scripts:reactor_fix

execute if score o2 sabotage matches 0.. run execute as @e[tag=o2_alert] run data merge entity @s {Glowing:1b}
execute if score reactor sabotage matches 0.. run execute as @e[tag=reactor_alert] run data merge entity @s {Glowing:1b}
execute if score reactor sabotage matches 0.. run execute as @e[tag=reactor_alert] run fill 750 163 1390 749 165 1391 minecraft:red_stained_glass
execute if score lights sabotage matches 0.. run execute as @e[tag=lights_alert] run data merge entity @s {Glowing:1b}
execute if score comms sabotage matches 0.. run execute as @e[tag=comms_alert] run data merge entity @s {Glowing:1b}
execute if score o2 sabotage matches -1 run execute as @e[tag=o2_alert] run data merge entity @s {Glowing:0b}
execute if score reactor sabotage matches -1 run execute as @e[tag=reactor_alert] run data merge entity @s {Glowing:0b}
execute if score reactor sabotage matches -1 run execute as @e[tag=reactor_alert] run fill 750 163 1390 749 165 1391 minecraft:white_stained_glass
execute if score lights sabotage matches -1 run execute as @e[tag=lights_alert] run data merge entity @s {Glowing:0b}
execute if score comms sabotage matches -1 run execute as @e[tag=comms_alert] run data merge entity @s {Glowing:0b}

## Sabotage timers
execute if score o2 sabotage matches 1.. run scoreboard players remove o2 sabotage 1
execute if score reactor sabotage matches 1.. run scoreboard players remove reactor sabotage 1

function scripts:comms_fix

execute if score lights sabotage matches 1.. unless entity @e[tag=in_meeting] run effect give @a[tag=crewmate,tag=!ghost,tag=!surveil] blindness 2 0 true
effect clear @a[tag=surveil] blindness
function scripts:lights_fix


## Check if game ends
execute if score o2 sabotage matches 0 run function scripts:game_check
execute if score reactor sabotage matches 0 run function scripts:game_check
execute if entity @e[tag=task] unless entity @e[tag=incomplete] run function scripts:crewmate_win

## Sprite in admin map
function scripts:sprites_map


## Fail-safe if no tasks left but bar is not full?

## Vote UI
function scripts:vote_confirm
execute if entity @a[tag=in_meeting] unless entity @a[scores={vote_id=-1}] run function scripts:vote_count

## Vote timer
execute if score timer vote_timer matches 1.. run scoreboard players remove timer vote_timer 1
execute store result bossbar minecraft:vote_timer value run scoreboard players get timer vote_timer
execute if score timer vote_timer matches 0 run function scripts:voting_runout

execute if score timer vote_timer matches 140 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1
execute if score timer vote_timer matches 120 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.05
execute if score timer vote_timer matches 100 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.10
execute if score timer vote_timer matches 80 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.15
execute if score timer vote_timer matches 60 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.20
execute if score timer vote_timer matches 40 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.25
execute if score timer vote_timer matches 20 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.30

## Vote particle
execute as @a[tag=!ghost,scores={vote_id=11}] at @s run particle minecraft:dust 0 1 1 1 ~ ~2.55 ~ 0.0 0.02 0.0 1.0 0 force

## Decon
execute if block 759 162 1418 crimson_button[powered=true] run execute if score p1 decon matches 0 if score p2 decon matches 0 run scoreboard players set p1 decon 180
execute if block 756 162 1415 crimson_button[powered=true] run execute if score p1 decon matches 0 if score p2 decon matches 0 run scoreboard players set p1 decon 180
execute if block 758 162 1401 crimson_button[powered=true] run execute if score p1 decon matches 0 if score p2 decon matches 0 run scoreboard players set p2 decon 180
execute if block 756 162 1405 crimson_button[powered=true] run execute if score p1 decon matches 0 if score p2 decon matches 0 run scoreboard players set p2 decon 180

execute if score p1 decon matches 1.. run scoreboard players remove p1 decon 1
execute if score p2 decon matches 1.. run scoreboard players remove p2 decon 1

# p1
execute if score p1 decon matches 179 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~1 ~ air replace blue_ice
execute if score p1 decon matches 179 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 120 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~1 ~ blue_ice replace air
execute if score p1 decon matches 120 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 80..120 run particle cloud 757 161 1414 0.0 0.0 0.0 1.0 10 force
execute if score p1 decon matches 80..120 run particle cloud 757 161 1410 0.0 0.0 0.0 1.0 10 force
execute if score p1 decon matches 80..120 run particle cloud 757 161 1406 0.0 0.0 0.0 1.0 10 force
execute if score p1 decon matches 120 positioned 757 160 1410 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p1 decon matches 60 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~1 ~ air replace blue_ice
execute if score p1 decon matches 60 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 1 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~1 ~ blue_ice replace air
execute if score p1 decon matches 1 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5

# p2
execute if score p2 decon matches 179 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~1 ~ air replace blue_ice
execute if score p2 decon matches 179 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 120 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~1 ~ blue_ice replace air
execute if score p2 decon matches 120 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 80..120 run particle cloud 757 161 1414 0.0 0.0 0.0 1.0 10 force
execute if score p2 decon matches 80..120 run particle cloud 757 161 1410 0.0 0.0 0.0 1.0 10 force
execute if score p2 decon matches 80..120 run particle cloud 757 161 1406 0.0 0.0 0.0 1.0 10 force
execute if score p2 decon matches 120 positioned 757 160 1410 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p2 decon matches 60 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~1 ~ air replace blue_ice
execute if score p2 decon matches 60 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 1 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~1 ~ blue_ice replace air
execute if score p2 decon matches 1 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5

## Door Logs
execute as @a if score @s door_log_cd matches 1.. run scoreboard players remove @s door_log_cd 1
execute if score comms sabotage matches -1 run execute as @e[tag=sensor] at @s as @p[team=playing,distance=..0.5,scores={door_log_cd=0}] at @s run function scripts:door_log_trigger


## Environment
particle minecraft:falling_dust snow 781 171 1376 5 0 5 0 10 force

