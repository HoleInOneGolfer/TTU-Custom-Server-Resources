scoreboard objectives add diagnostic dummy
execute as @a at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 9999 2.0

## Crewmate/Impostor
scoreboard players set diagnostic diagnostic 1800
setblock 739 162 1418 air