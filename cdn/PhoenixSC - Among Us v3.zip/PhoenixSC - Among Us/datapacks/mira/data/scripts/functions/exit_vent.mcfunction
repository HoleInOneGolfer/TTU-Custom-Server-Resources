tag @s remove venting
tag @s remove vent_system1
scoreboard players reset @s vent_number

## Move out
#setblock ~ ~-1 ~ minecraft:iron_trapdoor[open=true,half=top]
#schedule function scripts:reset_trapdoors 5
execute at @s run tp @s ~ ~1 ~
effect clear @s invisibility
execute as @s at @s run playsound minecraft:vent master @s ~ ~ ~ 9999

clear @s