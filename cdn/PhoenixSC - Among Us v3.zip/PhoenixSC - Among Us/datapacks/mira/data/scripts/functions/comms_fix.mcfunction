execute if block 773 162 1385 minecraft:redstone_lamp[lit=true] if block 776 162 1410 minecraft:redstone_lamp[lit=true] if score comms sabotage matches 1.. run execute as @a at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
execute if block 773 162 1385 minecraft:redstone_lamp[lit=true] if block 776 162 1410 minecraft:redstone_lamp[lit=true] if score comms sabotage matches 1.. run title @a title {"text":""}
execute if block 773 162 1385 minecraft:redstone_lamp[lit=true] if block 776 162 1410 minecraft:redstone_lamp[lit=true] if score comms sabotage matches 1.. run title @a subtitle {"text":"Comms restored"}
execute if block 773 162 1385 minecraft:redstone_lamp[lit=true] if block 776 162 1410 minecraft:redstone_lamp[lit=true] if score comms sabotage matches 1.. run scoreboard players set cd sabotage 340

execute if block 773 162 1385 minecraft:redstone_lamp[lit=true] if block 776 162 1410 minecraft:redstone_lamp[lit=true] run scoreboard players set comms sabotage -1
