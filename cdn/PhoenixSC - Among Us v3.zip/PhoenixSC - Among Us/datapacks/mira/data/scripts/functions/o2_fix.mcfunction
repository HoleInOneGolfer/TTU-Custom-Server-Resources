execute as @e[tag=o2_sabotage] at @s if block ~ ~ ~ lever[face=wall,facing=east,powered=true] run setblock ~ ~ ~ air

execute if block 753 162 1423 minecraft:redstone_lamp[lit=true] if block 784 161 1373 air if block 784 161 1372 air if block 784 161 1371 air if block 784 161 1370 air if score o2 sabotage matches 1.. run execute as @a at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
execute if block 753 162 1423 minecraft:redstone_lamp[lit=true] if block 784 161 1373 air if block 784 161 1372 air if block 784 161 1371 air if block 784 161 1370 air if score o2 sabotage matches 1.. run scoreboard players set cd sabotage 340
execute if block 753 162 1423 minecraft:redstone_lamp[lit=true] if block 784 161 1373 air if block 784 161 1372 air if block 784 161 1371 air if block 784 161 1370 air run scoreboard players set o2 sabotage -1

