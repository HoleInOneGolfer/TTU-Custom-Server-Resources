fill 762 3 1436 763 5 1436 air
fill 765 3 1436 766 5 1436 air

fill 762 3 1436 763 5 1436 chest[facing=south,type=single]
fill 765 3 1436 766 5 1436 chest[facing=south,type=single]

execute if score stage game_track matches 0 run function scripts:randomisers/7
execute if score var2 var matches 0 run clone 764 7 1440 764 7 1440 762 3 1436
execute if score var2 var matches 1 run clone 764 7 1440 764 7 1440 763 4 1436
execute if score var2 var matches 2 run clone 764 7 1440 764 7 1440 762 5 1436
execute if score var2 var matches 3 run clone 764 7 1440 764 7 1440 763 5 1436
execute if score var2 var matches 4 run clone 764 7 1440 764 7 1440 766 3 1436
execute if score var2 var matches 5 run clone 764 7 1440 764 7 1440 765 4 1436
execute if score var2 var matches 6 run clone 764 7 1440 764 7 1440 766 5 1436

clear @a[x=761,y=2,z=1439,dx=6,dy=3,dz=1]