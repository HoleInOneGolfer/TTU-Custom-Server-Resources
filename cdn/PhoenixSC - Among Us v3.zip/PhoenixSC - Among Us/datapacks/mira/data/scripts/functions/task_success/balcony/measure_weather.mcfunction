execute as @a[x=711,y=2,z=1450,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=711,y=2,z=1450,dx=6,dy=3,dz=1] @e[tag=balcony,tag=measure_weather,limit=1]

execute as @e[tag=balcony,tag=measure_weather,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/balcony/measure_weather
