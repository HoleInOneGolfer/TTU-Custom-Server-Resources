execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] if score lights sabotage matches 1.. run execute as @a at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] if score lights sabotage matches 1.. run execute as @a at @s run effect clear @a[tag=crewmate] blindness
execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] if score lights sabotage matches 1.. run title @a title {"text":""}
execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] if score lights sabotage matches 1.. run title @a subtitle {"text":"Lights restored"}
execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] if score lights sabotage matches 1.. run scoreboard players set cd sabotage 340

execute if block 773 162 1379 redstone_lamp[lit=true] if block 774 162 1379 redstone_lamp[lit=true] if block 775 162 1379 redstone_lamp[lit=true] if block 776 162 1379 redstone_lamp[lit=true] run scoreboard players set lights sabotage -1

## Default position
execute if score lights sabotage matches -1 run fill 773 163 1380 776 163 1380 lever[powered=true,face=wall,facing=south]
execute if score lights sabotage matches -1 run fill 773 162 1379 776 162 1379 redstone_lamp[lit=true]
