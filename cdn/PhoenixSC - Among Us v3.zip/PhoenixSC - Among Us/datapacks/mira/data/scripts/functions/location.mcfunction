execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=launchpad] run scoreboard players set @s location 1
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=locker_room] run scoreboard players set @s location 2
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=reactor] run scoreboard players set @s location 3
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=laboratory] run scoreboard players set @s location 4
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=med_bay] run scoreboard players set @s location 5
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=communications] run scoreboard players set @s location 6
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=office] run scoreboard players set @s location 7
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=greenhouse] run scoreboard players set @s location 8
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=admin] run scoreboard players set @s location 9
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=cafeteria] run scoreboard players set @s location 10
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=storage] run scoreboard players set @s location 11
execute at @e[limit=1,sort=nearest,tag=task] if entity @e[distance=..0.1,tag=balcony] run scoreboard players set @s location 12

