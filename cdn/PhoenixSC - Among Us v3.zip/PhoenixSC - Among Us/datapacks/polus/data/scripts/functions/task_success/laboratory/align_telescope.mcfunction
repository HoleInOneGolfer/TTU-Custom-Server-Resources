execute as @a[x=836,y=6,z=766,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=836,y=6,z=766,dx=6,dy=3,dz=1] lever
clear @a[x=836,y=6,z=766,dx=6,dy=3,dz=1] netherite_pickaxe

tp @a[x=836,y=6,z=766,dx=6,dy=3,dz=1] @e[tag=laboratory,tag=align_telescope,limit=1]

execute as @e[tag=laboratory,tag=align_telescope,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/align_telescope

