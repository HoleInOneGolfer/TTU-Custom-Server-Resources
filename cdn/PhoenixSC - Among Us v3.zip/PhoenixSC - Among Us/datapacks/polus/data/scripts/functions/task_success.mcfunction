## Dropship
execute if entity @e[tag=dropship,tag=chart_course,tag=incomplete] if block 827 9 731 minecraft:redstone_lamp[lit=true] if block 828 8 731 minecraft:redstone_lamp[lit=true] if block 829 7 731 minecraft:redstone_lamp[lit=true] if block 830 8 731 minecraft:redstone_lamp[lit=true] if block 831 7 731 minecraft:redstone_lamp[lit=true] run function scripts:task_success/dropship/chart
execute if entity @e[tag=dropship,tag=insert_keys,tag=incomplete] if block 839 8 728 minecraft:redstone_lamp[lit=true] run function scripts:task_success/dropship/insert_keys

## Security
execute if entity @e[tag=security,tag=fix_wiring,tag=incomplete] if block 846 7 728 minecraft:redstone_lamp[lit=true] if block 848 7 728 minecraft:redstone_lamp[lit=true] if block 850 7 728 minecraft:redstone_lamp[lit=true] if block 852 7 728 minecraft:redstone_lamp[lit=true] run function scripts:task_success/security/fix_wiring
execute if entity @e[tag=security,tag=upload_data,tag=incomplete] if block 862 7 728 minecraft:command_block{powered:1b} run function scripts:task_success/security/upload_data

## O2
execute if entity @e[tag=o2,tag=fix_wiring,tag=incomplete] if block 866 7 728 minecraft:redstone_lamp[lit=true] if block 868 7 728 minecraft:redstone_lamp[lit=true] if block 870 7 728 minecraft:redstone_lamp[lit=true] if block 872 7 728 minecraft:redstone_lamp[lit=true] run function scripts:task_success/o2/fix_wiring
execute if entity @e[tag=o2,tag=upload_data,tag=incomplete] if block 882 7 728 minecraft:command_block{powered:1b} run function scripts:task_success/o2/upload_data
execute if entity @e[tag=o2,tag=monitor_tree,tag=incomplete] if block 886 8 731 minecraft:redstone_lamp[lit=true] if block 887 8 731 minecraft:redstone_lamp[lit=true] if block 888 8 731 minecraft:redstone_lamp[lit=true] if block 889 8 731 minecraft:redstone_lamp[lit=true] if block 890 8 731 minecraft:redstone_lamp[lit=true] if block 886 7 731 minecraft:redstone_lamp[lit=true] if block 887 7 731 minecraft:redstone_lamp[lit=true] run function scripts:task_success/o2/monitor_tree
execute if entity @e[tag=o2,tag=fill_canisters,tag=incomplete] if blocks 897 7 730 897 7 730 899 11 731 all run function scripts:task_success/o2/fill_canisters
execute if entity @e[tag=o2,tag=empty_garbage,tag=incomplete] if blocks 827 6 741 831 7 740 827 11 741 all run function scripts:task_success/o2/empty_garbage

## Boiler Room
execute if entity @e[tag=boiler_room,tag=refill_water,tag=incomplete] if blocks 842 7 741 842 7 741 842 11 742 all run function scripts:task_success/boiler_room/refill_water
execute if entity @e[tag=boiler_room,tag=open_waterways1,tag=incomplete] if block 846 7 742 water if block 846 7 741 water if block 846 7 740 water if block 852 7 742 water if block 852 7 741 water if block 852 7 740 water if block 847 9 741 water if block 848 9 741 water if block 849 9 741 water if block 850 9 741 water if block 851 9 741 water run function scripts:task_success/boiler_room/open_waterways1
execute if entity @e[tag=boiler_room,tag=open_waterways2,tag=incomplete] if block 856 7 742 water if block 856 7 741 water if block 856 7 740 water if block 862 7 742 water if block 862 7 741 water if block 862 7 740 water if block 857 9 741 water if block 858 9 741 water if block 859 9 741 water if block 860 9 741 water if block 861 9 741 water run function scripts:task_success/boiler_room/open_waterways2

## Communications
execute if entity @e[tag=communications,tag=reboot_wifi,tag=incomplete] if score reboot_wifi reboot_wifi matches 0 run function scripts:task_success/communications/reboot_wifi
execute if entity @e[tag=communications,tag=upload_data,tag=incomplete] if block 866 7 739 minecraft:command_block{powered:1b} run function scripts:task_success/communications/upload_data

## Weapons
execute if entity @e[tag=weapons,tag=upload_data,tag=incomplete] if block 882 7 739 minecraft:command_block{powered:1b} run function scripts:task_success/weapons/upload_data
execute if entity @e[tag=weapons,tag=clear_asteroids,tag=incomplete] if blocks 892 7 743 886 9 740 886 14 740 all run function scripts:task_success/weapons/clear_asteroids

## Storage
execute if entity @e[tag=storage,tag=fuel1,tag=incomplete] if block 899 6 741 air run function scripts:task_success/storage/fuel1
execute if entity @e[tag=storage,tag=fuel2,tag=incomplete] if block 829 6 752 air run function scripts:task_success/storage/fuel2

## Office
execute if entity @e[tag=office,tag=refill_water,tag=incomplete] if blocks 842 7 752 842 7 752 842 11 752 all run function scripts:task_success/office/refill_water
execute if entity @e[tag=office,tag=fix_wiring,tag=incomplete] if block 846 7 750 redstone_lamp[lit=true] if block 848 7 750 redstone_lamp[lit=true] if block 850 7 750 redstone_lamp[lit=true] if block 852 7 750 redstone_lamp[lit=true] run function scripts:task_success/office/fix_wiring
execute if entity @e[tag=office,tag=swipe_card,tag=incomplete] if block 861 7 751 redstone_lamp[lit=true] run function scripts:task_success/office/swipe_card
execute if entity @e[tag=office,tag=scan_boarding,tag=incomplete] if block 868 7 751 redstone_lamp[lit=true] run function scripts:task_success/office/scan_boarding
execute if entity @e[tag=office,tag=upload_data,tag=incomplete] if block 882 7 750 minecraft:command_block{powered:1b} run function scripts:task_success/office/upload_data

## Laboratory
execute if entity @e[tag=laboratory,tag=repair_drill,tag=incomplete] if block 890 7 751 stone_bricks if block 890 7 753 stone_bricks if block 888 7 751 stone_bricks if block 888 7 753 stone_bricks if block 890 9 751 stone_bricks if block 890 9 753 stone_bricks if block 888 9 751 stone_bricks if block 888 9 753 stone_bricks run function scripts:task_success/laboratory/repair_drill
execute if entity @e[tag=laboratory,tag=fix_weather,tag=incomplete] if block 896 8 751 minecraft:redstone_lamp[lit=true] if block 898 8 751 minecraft:redstone_lamp[lit=true] if block 901 8 751 minecraft:redstone_lamp[lit=true] if block 897 8 753 minecraft:redstone_lamp[lit=true] if block 900 8 753 minecraft:redstone_lamp[lit=true] if block 902 8 753 minecraft:redstone_lamp[lit=true] run function scripts:task_success/laboratory/fix_weather
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 white_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=false] if block 828 7 765 minecraft:redstone_lamp[lit=false] if block 829 7 765 minecraft:redstone_lamp[lit=false] if block 830 7 765 minecraft:redstone_lamp[lit=false] if block 831 7 765 minecraft:redstone_lamp[lit=false] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 orange_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=false] if block 829 7 765 minecraft:redstone_lamp[lit=false] if block 830 7 765 minecraft:redstone_lamp[lit=false] if block 831 7 765 minecraft:redstone_lamp[lit=false] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 magenta_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=true] if block 829 7 765 minecraft:redstone_lamp[lit=false] if block 830 7 765 minecraft:redstone_lamp[lit=false] if block 831 7 765 minecraft:redstone_lamp[lit=false] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 light_blue_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=true] if block 829 7 765 minecraft:redstone_lamp[lit=true] if block 830 7 765 minecraft:redstone_lamp[lit=false] if block 831 7 765 minecraft:redstone_lamp[lit=false] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 yellow_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=true] if block 829 7 765 minecraft:redstone_lamp[lit=true] if block 830 7 765 minecraft:redstone_lamp[lit=true] if block 831 7 765 minecraft:redstone_lamp[lit=false] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 lime_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=true] if block 829 7 765 minecraft:redstone_lamp[lit=true] if block 830 7 765 minecraft:redstone_lamp[lit=true] if block 831 7 765 minecraft:redstone_lamp[lit=true] if block 832 7 765 minecraft:redstone_lamp[lit=false] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=record_temperature,tag=incomplete] if block 829 25 764 pink_wool if block 826 7 765 minecraft:redstone_lamp[lit=true] if block 827 7 765 minecraft:redstone_lamp[lit=true] if block 828 7 765 minecraft:redstone_lamp[lit=true] if block 829 7 765 minecraft:redstone_lamp[lit=true] if block 830 7 765 minecraft:redstone_lamp[lit=true] if block 831 7 765 minecraft:redstone_lamp[lit=true] if block 832 7 765 minecraft:redstone_lamp[lit=true] run function scripts:task_success/laboratory/record_temperature
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 white_wool if block 837 9 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 orange_wool if block 839 9 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 magenta_wool if block 837 8 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 light_blue_wool if block 839 8 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 yellow_wool if block 839 7 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 lime_wool if block 842 7 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=align_telescope,tag=incomplete] if block 839 25 764 pink_wool if block 836 7 765 lever run function scripts:task_success/laboratory/align_telescope
execute if entity @e[tag=laboratory,tag=inspect_sample,tag=incomplete] if score inspect_sample inspect_sample matches 0 run function scripts:task_success/laboratory/inspect_sample
execute if entity @e[tag=laboratory,tag=fix_wiring_a,tag=incomplete] if block 846 7 761 redstone_lamp[lit=true] if block 848 7 761 redstone_lamp[lit=true] if block 850 7 761 redstone_lamp[lit=true] if block 852 7 761 redstone_lamp[lit=true] run function scripts:task_success/laboratory/fix_wiring_a
execute if entity @e[tag=laboratory,tag=fix_wiring_b,tag=incomplete] if block 856 7 761 redstone_lamp[lit=true] if block 858 7 761 redstone_lamp[lit=true] if block 860 7 761 redstone_lamp[lit=true] if block 862 7 761 redstone_lamp[lit=true] run function scripts:task_success/laboratory/fix_wiring_b
execute if entity @e[tag=laboratory,tag=fix_wiring_c,tag=incomplete] if block 866 7 761 redstone_lamp[lit=true] if block 868 7 761 redstone_lamp[lit=true] if block 870 7 761 redstone_lamp[lit=true] if block 872 7 761 redstone_lamp[lit=true] run function scripts:task_success/laboratory/fix_wiring_c
execute if entity @e[tag=laboratory,tag=submit_scan,tag=incomplete] if score submit_scan submit_scan matches 0 run function scripts:task_success/laboratory/submit_scan

## Specimen Room
execute if entity @e[tag=specimen_room,tag=upload_data,tag=incomplete] if block 882 7 761 minecraft:command_block{powered:1b} run function scripts:task_success/specimen_room/upload_data
execute if entity @e[tag=specimen_room,tag=store_artifacts,tag=incomplete] if blocks 887 7 762 891 7 764 887 12 762 all run function scripts:task_success/specimen_room/store_artifacts
execute if entity @e[tag=specimen_room,tag=start_reactor,tag=incomplete] if blocks 899 7 764 899 7 764 899 11 764 all run function scripts:task_success/specimen_room/start_reactor
execute if entity @e[tag=specimen_room,tag=unlock_manifolds,tag=incomplete] if block 827 7 773 minecraft:redstone_lamp[lit=true] if block 827 7 775 minecraft:redstone_lamp[lit=true] if block 829 7 774 minecraft:redstone_lamp[lit=true] if block 831 7 773 minecraft:redstone_lamp[lit=true] if block 831 7 775 minecraft:redstone_lamp[lit=true] run function scripts:task_success/specimen_room/unlock_manifolds

## Exterior
execute if entity @e[tag=exterior,tag=fuel1,tag=incomplete] if blocks 838 6 773 840 6 775 838 11 774 all run function scripts:task_success/exterior/fuel1
execute if entity @e[tag=exterior,tag=fuel2,tag=incomplete] if blocks 848 6 773 850 6 775 838 11 774 all run function scripts:task_success/exterior/fuel2

execute if entity @e[tag=exterior,tag=fix_weather1,tag=incomplete] if block 859 25 775 white_wool if blocks 857 9 775 861 6 775 865 11 771 all run function scripts:task_success/exterior/fix_weather1
execute if entity @e[tag=exterior,tag=fix_weather1,tag=incomplete] if block 859 25 775 orange_wool if blocks 857 9 775 861 6 775 875 11 771 all run function scripts:task_success/exterior/fix_weather1
execute if entity @e[tag=exterior,tag=fix_weather1,tag=incomplete] if block 859 25 775 magenta_wool if blocks 857 9 775 861 6 775 885 11 771 all run function scripts:task_success/exterior/fix_weather1
execute if entity @e[tag=exterior,tag=fix_weather1,tag=incomplete] if block 859 25 775 light_blue_wool if blocks 857 9 775 861 6 775 895 11 771 all run function scripts:task_success/exterior/fix_weather1
execute if entity @e[tag=exterior,tag=fix_weather1,tag=incomplete] if block 859 25 775 yellow_wool if blocks 857 9 775 861 6 775 825 11 782 all run function scripts:task_success/exterior/fix_weather1

execute if entity @e[tag=exterior,tag=fix_weather2,tag=incomplete] if block 869 25 775 white_wool if blocks 867 9 775 871 6 775 865 11 771 all run function scripts:task_success/exterior/fix_weather2
execute if entity @e[tag=exterior,tag=fix_weather2,tag=incomplete] if block 869 25 775 orange_wool if blocks 867 9 775 871 6 775 875 11 771 all run function scripts:task_success/exterior/fix_weather2
execute if entity @e[tag=exterior,tag=fix_weather2,tag=incomplete] if block 869 25 775 magenta_wool if blocks 867 9 775 871 6 775 885 11 771 all run function scripts:task_success/exterior/fix_weather2
execute if entity @e[tag=exterior,tag=fix_weather2,tag=incomplete] if block 869 25 775 light_blue_wool if blocks 867 9 775 871 6 775 895 11 771 all run function scripts:task_success/exterior/fix_weather2
execute if entity @e[tag=exterior,tag=fix_weather2,tag=incomplete] if block 869 25 775 yellow_wool if blocks 867 9 775 871 6 775 825 11 782 all run function scripts:task_success/exterior/fix_weather2

execute if entity @e[tag=exterior,tag=fix_weather3,tag=incomplete] if block 879 25 775 white_wool if blocks 877 9 775 881 6 775 865 11 771 all run function scripts:task_success/exterior/fix_weather3
execute if entity @e[tag=exterior,tag=fix_weather3,tag=incomplete] if block 879 25 775 orange_wool if blocks 877 9 775 881 6 775 875 11 771 all run function scripts:task_success/exterior/fix_weather3
execute if entity @e[tag=exterior,tag=fix_weather3,tag=incomplete] if block 879 25 775 magenta_wool if blocks 877 9 775 881 6 775 885 11 771 all run function scripts:task_success/exterior/fix_weather3
execute if entity @e[tag=exterior,tag=fix_weather3,tag=incomplete] if block 879 25 775 light_blue_wool if blocks 877 9 775 881 6 775 895 11 771 all run function scripts:task_success/exterior/fix_weather3
execute if entity @e[tag=exterior,tag=fix_weather3,tag=incomplete] if block 879 25 775 yellow_wool if blocks 877 9 775 881 6 775 825 11 782 all run function scripts:task_success/exterior/fix_weather3

execute if entity @e[tag=exterior,tag=fix_weather4,tag=incomplete] if block 889 25 775 white_wool if blocks 887 9 775 891 6 775 865 11 771 all run function scripts:task_success/exterior/fix_weather4
execute if entity @e[tag=exterior,tag=fix_weather4,tag=incomplete] if block 889 25 775 orange_wool if blocks 887 9 775 891 6 775 875 11 771 all run function scripts:task_success/exterior/fix_weather4
execute if entity @e[tag=exterior,tag=fix_weather4,tag=incomplete] if block 889 25 775 magenta_wool if blocks 887 9 775 891 6 775 885 11 771 all run function scripts:task_success/exterior/fix_weather4
execute if entity @e[tag=exterior,tag=fix_weather4,tag=incomplete] if block 889 25 775 light_blue_wool if blocks 887 9 775 891 6 775 895 11 771 all run function scripts:task_success/exterior/fix_weather4
execute if entity @e[tag=exterior,tag=fix_weather4,tag=incomplete] if block 889 25 775 yellow_wool if blocks 887 9 775 891 6 775 825 11 782 all run function scripts:task_success/exterior/fix_weather4

execute if entity @e[tag=exterior,tag=open_waterways1,tag=incomplete] if block 896 7 775 water if block 896 7 774 water if block 896 7 773 water if block 902 7 775 water if block 902 7 774 water if block 902 7 773 water if block 897 9 774 water if block 898 9 774 water if block 899 9 774 water if block 900 9 774 water if block 901 9 774 water run function scripts:task_success/exterior/open_waterways1
execute if entity @e[tag=exterior,tag=open_waterways2,tag=incomplete] if block 826 7 786 water if block 826 7 785 water if block 826 7 784 water if block 832 7 786 water if block 832 7 785 water if block 832 7 784 water if block 827 9 785 water if block 828 9 785 water if block 829 9 785 water if block 830 9 785 water if block 831 9 785 water run function scripts:task_success/exterior/open_waterways2

execute if entity @e[tag=exterior,tag=fix_weather5,tag=incomplete] if block 839 25 786 white_wool if blocks 837 9 786 841 6 786 865 11 771 all run function scripts:task_success/exterior/fix_weather5
execute if entity @e[tag=exterior,tag=fix_weather5,tag=incomplete] if block 839 25 786 orange_wool if blocks 837 9 786 841 6 786 875 11 771 all run function scripts:task_success/exterior/fix_weather5
execute if entity @e[tag=exterior,tag=fix_weather5,tag=incomplete] if block 839 25 786 magenta_wool if blocks 837 9 786 841 6 786 885 11 771 all run function scripts:task_success/exterior/fix_weather5
execute if entity @e[tag=exterior,tag=fix_weather5,tag=incomplete] if block 839 25 786 light_blue_wool if blocks 837 9 786 841 6 786 895 11 771 all run function scripts:task_success/exterior/fix_weather5
execute if entity @e[tag=exterior,tag=fix_weather5,tag=incomplete] if block 839 25 786 yellow_wool if blocks 837 9 786 841 6 786 825 11 782 all run function scripts:task_success/exterior/fix_weather5

execute if entity @e[tag=exterior,tag=fix_weather6,tag=incomplete] if block 849 25 786 white_wool if blocks 847 9 786 851 6 786 865 11 771 all run function scripts:task_success/exterior/fix_weather6
execute if entity @e[tag=exterior,tag=fix_weather6,tag=incomplete] if block 849 25 786 orange_wool if blocks 847 9 786 851 6 786 875 11 771 all run function scripts:task_success/exterior/fix_weather6
execute if entity @e[tag=exterior,tag=fix_weather6,tag=incomplete] if block 849 25 786 magenta_wool if blocks 847 9 786 851 6 786 885 11 771 all run function scripts:task_success/exterior/fix_weather6
execute if entity @e[tag=exterior,tag=fix_weather6,tag=incomplete] if block 849 25 786 light_blue_wool if blocks 847 9 786 851 6 786 895 11 771 all run function scripts:task_success/exterior/fix_weather6
execute if entity @e[tag=exterior,tag=fix_weather6,tag=incomplete] if block 849 25 786 yellow_wool if blocks 847 9 786 851 6 786 825 11 782 all run function scripts:task_success/exterior/fix_weather6

execute if entity @e[tag=exterior,tag=record_temperature,tag=incomplete] if blocks 856 7 787 862 7 787 856 11 786 all run function scripts:task_success/exterior/record_temperature
