execute as @a[x=836,y=6,z=744,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=836,y=6,z=744,dx=6,dy=3,dz=1] water_bucket
clear @a[x=836,y=6,z=744,dx=6,dy=3,dz=1] bucket

tp @a[x=836,y=6,z=744,dx=6,dy=3,dz=1] @e[tag=boiler_room,tag=refill_water,limit=1]

execute as @e[tag=boiler_room,tag=refill_water,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/boiler_room/refill_water

execute as @e[tag=office,tag=refill_water,limit=1] run function scripts:increment_task