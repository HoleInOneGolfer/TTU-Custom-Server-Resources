execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] if score lights sabotage matches 1.. run execute as @a at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] if score lights sabotage matches 1.. run execute as @a at @s run effect clear @a[tag=crewmate] blindness
execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] if score lights sabotage matches 1.. run title @a title {"text":""}
execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] if score lights sabotage matches 1.. run title @a subtitle {"text":"Lights restored"}
execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] if score lights sabotage matches 1.. run scoreboard players set cd sabotage 340

execute if block 705 32 810 redstone_lamp[lit=true] if block 703 32 813 redstone_lamp[lit=true] if block 706 32 813 redstone_lamp[lit=true] if block 703 32 816 redstone_lamp[lit=true] if block 706 32 816 redstone_lamp[lit=true] run scoreboard players set lights sabotage -1

## Default position
execute if score lights sabotage matches -1 run setblock 704 32 811 lever[face=wall,facing=south,powered=true]
execute if score lights sabotage matches -1 run setblock 702 32 814 lever[face=wall,facing=south,powered=true]
execute if score lights sabotage matches -1 run setblock 702 32 817 lever[face=wall,facing=south,powered=true]
execute if score lights sabotage matches -1 run setblock 707 32 814 lever[face=wall,facing=south,powered=true]
execute if score lights sabotage matches -1 run setblock 707 32 817 lever[face=wall,facing=south,powered=true]

execute if score lights sabotage matches -1 run setblock 705 32 810 redstone_lamp[lit=true]
execute if score lights sabotage matches -1 run setblock 703 32 813 redstone_lamp[lit=true]
execute if score lights sabotage matches -1 run setblock 706 32 813 redstone_lamp[lit=true]
execute if score lights sabotage matches -1 run setblock 703 32 816 redstone_lamp[lit=true]
execute if score lights sabotage matches -1 run setblock 706 32 816 redstone_lamp[lit=true]