fill 846 9 786 852 6 786 minecraft:purple_concrete
fill 846 9 787 852 6 787 barrier
fill 851 6 788 847 9 788 lever[face=wall,facing=south,powered=false]
execute if score stage game_track matches 0 run function scripts:randomisers/5
setblock 846 9 786 yellow_wool
setblock 852 6 786 lime_wool

execute if score var1 var matches 0 run clone 857 14 772 861 11 772 847 6 786
execute if score var1 var matches 1 run clone 857 14 773 861 11 773 847 6 786
execute if score var1 var matches 2 run clone 857 14 774 861 11 774 847 6 786
execute if score var1 var matches 3 run clone 857 14 775 861 11 775 847 6 786
execute if score var1 var matches 4 run clone 857 14 776 861 11 776 847 6 786

execute if score var1 var matches 0 run setblock 849 25 786 white_wool
execute if score var1 var matches 1 run setblock 849 25 786 orange_wool
execute if score var1 var matches 2 run setblock 849 25 786 magenta_wool
execute if score var1 var matches 3 run setblock 849 25 786 light_blue_wool
execute if score var1 var matches 4 run setblock 849 25 786 yellow_wool