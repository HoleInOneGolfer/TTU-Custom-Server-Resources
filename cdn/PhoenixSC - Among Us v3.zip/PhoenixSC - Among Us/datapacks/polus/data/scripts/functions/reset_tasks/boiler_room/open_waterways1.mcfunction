fill 846 8 742 846 8 740 lever[face=wall,facing=east,powered=false]
fill 852 8 740 852 8 742 lever[face=wall,facing=west,powered=false]
fill 851 9 740 847 9 740 lever[face=ceiling,facing=north,powered=false]
fill 847 6 742 851 6 740 air
fill 852 6 743 846 9 739 air replace water