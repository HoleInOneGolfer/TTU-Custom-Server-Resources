setblock 839 8 728 redstone_lamp[lit=false]
setblock 839 7 729 lever[face=wall,facing=south,powered=false]
setblock 840 8 732 air
clone 841 11 735 841 11 735 837 7 732

execute if score stage game_track matches 0 run function scripts:randomisers/5
execute if score var1 var matches 0 run clone 835 11 735 835 11 735 842 6 734
execute if score var1 var matches 1 run clone 836 11 735 836 11 735 842 6 734
execute if score var1 var matches 2 run clone 837 11 735 837 11 735 842 6 734
execute if score var1 var matches 3 run clone 838 11 735 838 11 735 842 6 734
execute if score var1 var matches 4 run clone 839 11 735 839 11 735 842 6 734

clear @a[x=836,y=6,z=733,dx=6,dy=3,dz=1]