execute as @a[x=856,y=6,z=755,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=856,y=6,z=755,dx=6,dy=3,dz=1] paper
tp @a[x=856,y=6,z=755,dx=6,dy=3,dz=1] @e[tag=office,tag=swipe_card,limit=1]

execute as @e[tag=office,tag=swipe_card,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/office/swipe_card
