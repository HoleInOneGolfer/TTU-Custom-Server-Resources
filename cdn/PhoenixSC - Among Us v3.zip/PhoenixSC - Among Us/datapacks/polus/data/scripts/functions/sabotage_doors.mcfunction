playsound minecraft:block.piston.extend master @s ~ ~ ~ 1 0.5

execute if score @s location matches 1 run scoreboard players set @e[tag=door] close_door 200
execute if score @s location matches 2..4 run scoreboard players set @e[tag=door,tag=electrical] close_door 200
execute if score @s location matches 2..4 run scoreboard players set @e[tag=door,tag=o2] close_door 200
execute if score @s location matches 5 run scoreboard players set @e[tag=door,tag=communications] close_door 200
execute if score @s location matches 6 run scoreboard players set @e[tag=door,tag=weapons] close_door 200
execute if score @s location matches 7 run scoreboard players set @e[tag=door,tag=storage] close_door 200
execute if score @s location matches 8 run scoreboard players set @e[tag=door,tag=office] close_door 200
execute if score @s location matches 9 run scoreboard players set @e[tag=door,tag=laboratory] close_door 200
execute if score @s location matches 10 run scoreboard players set @e[tag=door,tag=laboratory] close_door 200
execute if score @s location matches 11 run scoreboard players set @e[tag=door,tag=office] close_door 200
