execute as @a[x=896,y=6,z=744,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=896,y=6,z=744,dx=6,dy=3,dz=1] bucket
clear @a[x=896,y=6,z=744,dx=6,dy=3,dz=1] water_bucket
tp @a[x=896,y=6,z=744,dx=6,dy=3,dz=1] @e[tag=storage,tag=fuel1,limit=1]

execute as @e[tag=storage,tag=fuel1,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/storage/fuel1

execute as @e[tag=exterior,tag=fuel1,limit=1] run function scripts:increment_task
