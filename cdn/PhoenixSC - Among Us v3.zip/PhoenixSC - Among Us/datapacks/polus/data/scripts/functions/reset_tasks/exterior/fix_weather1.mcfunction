fill 856 9 775 862 6 775 minecraft:purple_concrete
fill 856 6 776 862 9 776 barrier
fill 857 9 777 861 6 777 lever[face=wall,facing=south,powered=false]
execute if score stage game_track matches 0 run function scripts:randomisers/5
setblock 856 9 775 yellow_wool
setblock 862 6 775 lime_wool

execute if score var1 var matches 0 run clone 857 14 772 861 11 772 857 6 775
execute if score var1 var matches 1 run clone 857 14 773 861 11 773 857 6 775
execute if score var1 var matches 2 run clone 857 14 774 861 11 774 857 6 775
execute if score var1 var matches 3 run clone 857 14 775 861 11 775 857 6 775
execute if score var1 var matches 4 run clone 857 14 776 861 11 776 857 6 775

execute if score var1 var matches 0 run setblock 859 25 775 white_wool
execute if score var1 var matches 1 run setblock 859 25 775 orange_wool
execute if score var1 var matches 2 run setblock 859 25 775 magenta_wool
execute if score var1 var matches 3 run setblock 859 25 775 light_blue_wool
execute if score var1 var matches 4 run setblock 859 25 775 yellow_wool
