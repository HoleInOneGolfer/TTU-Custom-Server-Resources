execute if score comms sabotage matches 0.. run playsound minecraft:comms_down master @p
execute if score comms sabotage matches 0.. run tellraw @p ["",{"text":"\n"},{"text":" Comms are down"},{"text":"\n"}]



execute if score comms sabotage matches -1 run tellraw @p {"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"}
execute if score comms sabotage matches -1 run execute as @p at @s run playsound minecraft:generic master @s
execute if score comms sabotage matches -1 run tellraw @p {"text":""}
execute if score comms sabotage matches -1 run tellraw @p {"text":"\n SIMSONG","bold":"true","color":"dark_aqua","italic":"true"}
execute if score comms sabotage matches -1 run tellraw @p {"text":" -----------------------------","color":"gray"}
execute if score comms sabotage matches -1 run execute unless entity @e[tag=ghost] run tellraw @p ["",{"text":" All vitals clear","bold":true,"color":"green"}]
execute if score comms sabotage matches -1 run execute if entity @e[tag=ghost,tag=!reported] run tellraw @p ["",{"text":" Dead: ","bold":true,"color":"red"},{"selector":"@a[tag=ghost,tag=!reported]","color":"gray"}]
execute if score comms sabotage matches -1 run execute if entity @e[tag=ghost,tag=reported] run tellraw @p ["",{"text":" D/C: ","bold":true,"color":"red"},{"selector":"@a[tag=ghost,tag=reported]","color":"gray"}]
execute if score comms sabotage matches -1 run tellraw @p {"text":""}