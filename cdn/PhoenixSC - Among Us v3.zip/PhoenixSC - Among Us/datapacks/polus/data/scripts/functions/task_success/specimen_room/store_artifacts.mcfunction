execute as @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] diamond
clear @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] blaze_rod
clear @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] jungle_leaves
clear @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] bone

tp @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] @e[tag=specimen_room,tag=store_artifacts,limit=1]

execute as @e[tag=specimen_room,tag=store_artifacts,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/specimen_room/store_artifacts

