execute as @e[tag=submit_scan,tag=laboratory] at @s as @p[distance=..5] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 9999

execute as @e[tag=laboratory,tag=submit_scan,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/submit_scan