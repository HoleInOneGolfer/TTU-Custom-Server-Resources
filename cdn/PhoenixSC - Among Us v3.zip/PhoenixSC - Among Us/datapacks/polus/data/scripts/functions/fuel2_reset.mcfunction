replaceitem entity @a[x=846,y=6,z=777,dx=6,dy=3,dz=1] weapon water_bucket{CanPlaceOn:["minecraft:cauldron"]}
fill 848 7 773 850 7 775 air