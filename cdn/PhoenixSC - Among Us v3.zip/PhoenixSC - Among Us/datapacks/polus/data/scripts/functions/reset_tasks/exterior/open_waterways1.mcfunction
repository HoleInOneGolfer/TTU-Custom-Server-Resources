fill 896 8 775 896 8 773 lever[face=wall,facing=east,powered=false]
fill 902 8 775 902 8 773 lever[face=wall,facing=west,powered=false]
fill 897 9 773 901 9 773 lever[face=ceiling,facing=north,powered=false]
fill 897 6 773 901 6 775 air
fill 896 9 772 902 6 776 air replace water