execute as @a[x=836,y=6,z=755,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=836,y=6,z=755,dx=6,dy=3,dz=1] bucket
clear @a[x=836,y=6,z=755,dx=6,dy=3,dz=1] water_bucket
tp @a[x=836,y=6,z=755,dx=6,dy=3,dz=1] @e[tag=office,tag=refill_water,limit=1]

execute as @e[tag=office,tag=refill_water,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/office/refill_water
