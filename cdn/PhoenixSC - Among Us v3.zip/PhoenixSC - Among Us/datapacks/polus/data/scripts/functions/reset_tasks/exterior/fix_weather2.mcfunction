fill 866 9 775 872 6 775 minecraft:purple_concrete
fill 866 6 776 872 9 776 barrier
fill 867 9 777 871 6 777 lever[face=wall,facing=south,powered=false]
execute if score stage game_track matches 0 run function scripts:randomisers/5
setblock 866 9 775 yellow_wool
setblock 872 6 775 lime_wool

execute if score var1 var matches 0 run clone 857 14 772 861 11 772 867 6 775
execute if score var1 var matches 1 run clone 857 14 773 861 11 773 867 6 775
execute if score var1 var matches 2 run clone 857 14 774 861 11 774 867 6 775
execute if score var1 var matches 3 run clone 857 14 775 861 11 775 867 6 775
execute if score var1 var matches 4 run clone 857 14 776 861 11 776 867 6 775

execute if score var1 var matches 0 run setblock 869 25 775 white_wool
execute if score var1 var matches 1 run setblock 869 25 775 orange_wool
execute if score var1 var matches 2 run setblock 869 25 775 magenta_wool
execute if score var1 var matches 3 run setblock 869 25 775 light_blue_wool
execute if score var1 var matches 4 run setblock 869 25 775 yellow_wool
