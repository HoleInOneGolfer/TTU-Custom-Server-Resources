fill 846 7 764 852 7 764 air
execute if score stage game_track matches 0 run function scripts:randomisers/5
execute if score var1 var matches 0 run clone 845 11 735 845 11 735 851 6 766
execute if score var1 var matches 1 run clone 846 11 735 846 11 735 851 6 766
execute if score var1 var matches 2 run clone 847 11 735 847 11 735 851 6 766
execute if score var1 var matches 3 run clone 848 11 735 848 11 735 851 6 766
execute if score var1 var matches 4 run clone 849 11 735 849 11 735 851 6 766
clear @a[x=846,y=6,z=766,dx=6,dy=3,dz=1]