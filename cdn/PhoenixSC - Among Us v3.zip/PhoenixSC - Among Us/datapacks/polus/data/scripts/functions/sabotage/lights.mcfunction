scoreboard players set lights sabotage 1
scoreboard players set cd sabotage 2000000
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Reactor","italic":"false"}'},HideFlags:63,CustomModelData:10}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Comms","italic":"false"}'},HideFlags:63,CustomModelData:11}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Lights","italic":"false"}'},HideFlags:63,CustomModelData:12}
execute as @a at @s run playsound minecraft:entity.silverfish.ambient master @s ~ ~ ~ 9999 2

title @a title {"text":""}
title @a subtitle {"text":"Lights are down"}

setblock 704 32 811 lever[face=wall,facing=south,powered=false]
setblock 702 32 814 lever[face=wall,facing=south,powered=false]
setblock 707 32 814 lever[face=wall,facing=south,powered=false]
setblock 702 32 817 lever[face=wall,facing=south,powered=false]
setblock 707 32 817 lever[face=wall,facing=south,powered=false]


setblock 705 32 810 redstone_lamp[lit=false]
setblock 703 32 813 redstone_lamp[lit=false]
setblock 703 32 816 redstone_lamp[lit=false]
setblock 706 32 813 redstone_lamp[lit=false]
setblock 706 32 816 redstone_lamp[lit=false]

