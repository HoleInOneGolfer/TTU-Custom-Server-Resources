## Crewmate
execute if entity @s[tag=crewmate] run tp @s 829 6 778 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked