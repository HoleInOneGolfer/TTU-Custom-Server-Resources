scoreboard objectives add inspect_sample dummy
execute as @a at @s run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 9999

## Crewmate/Impostor
scoreboard players set inspect_sample inspect_sample 900
setblock 768 32 799 air