execute as @a[x=826,y=6,z=788,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999

tp @a[x=826,y=6,z=788,dx=6,dy=3,dz=1] @e[tag=exterior,tag=open_waterways2,limit=1]

execute as @e[tag=exterior,tag=open_waterways2,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/exterior/open_waterways2