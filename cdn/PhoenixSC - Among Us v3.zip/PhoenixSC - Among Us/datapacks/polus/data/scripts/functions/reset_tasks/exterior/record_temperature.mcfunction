fill 856 6 788 862 6 788 lever[face=wall,facing=south,powered=false]
fill 856 7 787 862 7 787 minecraft:redstone_lamp[lit=false]
fill 856 9 787 862 9 787 yellow_wool