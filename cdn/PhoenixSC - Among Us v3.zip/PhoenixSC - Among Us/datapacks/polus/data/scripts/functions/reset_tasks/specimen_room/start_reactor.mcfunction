setblock 899 7 764 air
setblock 899 7 764 minecraft:dispenser[facing=south,triggered=false]
clone 895 11 768 895 11 768 901 6 766
clear @a[x=896,y=6,z=766,dx=6,dy=3,dz=1]