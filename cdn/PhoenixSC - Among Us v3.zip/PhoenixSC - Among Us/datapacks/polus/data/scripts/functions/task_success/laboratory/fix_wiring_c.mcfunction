execute as @a[x=866,y=6,z=766,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=866,y=6,z=766,dx=6,dy=3,dz=1] redstone
clear @a[x=866,y=6,z=766,dx=6,dy=3,dz=1] repeater

tp @a[x=866,y=6,z=766,dx=6,dy=3,dz=1] @e[tag=laboratory,tag=fix_wiring_c,limit=1]

execute as @e[tag=laboratory,tag=fix_wiring_c,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/fix_wiring_c

