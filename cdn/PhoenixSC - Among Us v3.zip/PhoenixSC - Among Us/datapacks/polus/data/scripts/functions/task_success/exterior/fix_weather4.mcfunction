execute as @a[x=886,y=6,z=777,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999

tp @a[x=886,y=6,z=777,dx=6,dy=3,dz=1] @e[tag=exterior,tag=fix_weather4,limit=1]

execute as @e[tag=exterior,tag=fix_weather4,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/exterior/fix_weather4

execute as @e[tag=laboratory,tag=fix_weather,limit=1] run function scripts:increment_task