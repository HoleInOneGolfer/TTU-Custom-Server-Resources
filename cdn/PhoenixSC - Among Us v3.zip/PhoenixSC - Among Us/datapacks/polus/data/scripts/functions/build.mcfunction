time set 18000

scoreboard objectives add click minecraft.used:minecraft.carrot_on_a_stick
kill @e[tag=task]
kill @e[tag=camera]
kill @e[tag=camera_marker]
kill @e[tag=SKIP_detect]
kill @e[tag=vent]
kill @e[tag=door]
kill @e[tag=decon_door]
kill @e[tag=model]
kill @e[tag=alert]
team add playing
team modify playing nametagVisibility never
team modify playing seeFriendlyInvisibles false
team modify playing collisionRule never
team add ghost
team modify ghost nametagVisibility never
team modify ghost seeFriendlyInvisibles true
team modify ghost collisionRule never
team add alert
team modify alert color red
gamemode adventure @a
kill @e[tag=dropship_spawn]
kill @e[tag=office_spawn]
kill @e[tag=camera_model]
execute as @e[type=item_frame] run data merge entity @s {Invisible:1b,Fixed:1b}
execute as @e[type=painting] run data merge entity @s {Invulnerable:1b}
execute as @e[type=armor_stand] run data merge entity @s {DisabledSlots:4144959}
gamerule sendCommandFeedback false
gamerule announceAdvancements false


## Task-markers
# Dropship
summon minecraft:armor_stand 721 34 781 {CustomName:'{"text":"Dropship"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","chart_course","dropship"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 724 34 781 {CustomName:'{"text":"Dropship"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","insert_keys","dropship"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Security
summon minecraft:armor_stand 688 31 805 {CustomName:'{"text":"Security"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","security"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 699 31 805 {CustomName:'{"text":"Security"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","upload_data","security"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# O2
summon minecraft:armor_stand 697 31 832 {CustomName:'{"text":"O2"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","o2"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 688 31 821 {CustomName:'{"text":"O2"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","upload_data","o2"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 685 31 825 {CustomName:'{"text":"O2"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","monitor_tree","o2"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 683 31 834 {CustomName:'{"text":"O2"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fill_canisters","o2"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 693 31 836 {CustomName:'{"text":"O2"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","empty_garbage","o2"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Boiler Room
summon minecraft:armor_stand 683 31 842 {CustomName:'{"text":"Boiler Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","refill_water","boiler_room"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 685 31 845 {CustomName:'{"text":"Boiler Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","open_waterways1","boiler_room"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}
summon minecraft:armor_stand 688 31 845 {CustomName:'{"text":"Boiler Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","open_waterways2","boiler_room"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}

# Communications
summon minecraft:armor_stand 707 31 822 {CustomName:'{"text":"Communications"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","reboot_wifi","communications"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 710 31 823 {CustomName:'{"text":"Communications"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","upload_data","communications"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Weapons
summon minecraft:armor_stand 716 31 839 {CustomName:'{"text":"Weapons"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","upload_data","weapons"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 707 31 841 {CustomName:'{"text":"Weapons"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","clear_asteroids","weapons"],DisabledSlots:4144959,Rotation:[90f],CustomNameVisible:0b}

# Storage
summon minecraft:armor_stand 732 31 811 {CustomName:'{"text":"Storage"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fuel1","storage"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 735 31 813 {CustomName:'{"text":"Storage"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fuel2","storage"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}

# Office
summon minecraft:armor_stand 724 31 822 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","refill_water","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 721 31 830 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 743 31 823 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","swipe_card","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 745 31 823 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","scan_boarding","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 750 31 822 {CustomName:'{"text":"Office"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","upload_data","office"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Laboratory
summon minecraft:armor_stand 747 31 802 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","repair_drill","laboratory"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 754 31 800 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","fix_weather","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 758 31 800 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","record_temperature","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 765 31 797 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","align_telescope","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 768 31 799 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","inspect_sample","laboratory"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 762 31 806 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring_a","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 773 31 806 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring_b","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 781 31 807 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","fix_wiring_c","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 781 32 801 {CustomName:'{"text":"Laboratory"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","submit_scan","laboratory"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}

# Specimen Room
summon minecraft:armor_stand 777 31 834 {CustomName:'{"text":"Specimen Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","upload_data","specimen_room"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 771 31 832 {CustomName:'{"text":"Specimen Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","store_artifacts","specimen_room"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 766 31 832 {CustomName:'{"text":"Specimen Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","start_reactor","specimen_room"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 766 31 838 {CustomName:'{"text":"Specimen Room"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","unlock_manifolds","specimen_room"],DisabledSlots:4144959,Rotation:[0f],CustomNameVisible:0b}

# Exterior
summon minecraft:armor_stand 710 31 801 {CustomName:'{"text":"Exterior (North)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","fuel1","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 735 31 801 {CustomName:'{"text":"Exterior (North)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","fuel2","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 718 31 813 {CustomName:'{"text":"Exterior (North)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather1","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 702 31 824 {CustomName:'{"text":"Exterior (West)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather2","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 698 31 848 {CustomName:'{"text":"Exterior (South)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather3","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 719 31 846 {CustomName:'{"text":"Exterior (South)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather4","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 726 31 844 {CustomName:'{"text":"Exterior (South)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","open_waterways1","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 772 31 813 {CustomName:'{"text":"Exterior (East)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","part2","open_waterways2","exterior"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 737 31 804 {CustomName:'{"text":"Exterior (North)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather5","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}
summon minecraft:armor_stand 752 31 816 {CustomName:'{"text":"Exterior (East)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","long","selectable","fix_weather6","exterior"],DisabledSlots:4144959,Rotation:[270f],CustomNameVisible:0b}
summon minecraft:armor_stand 755 31 822 {CustomName:'{"text":"Exterior (East)"}',NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["task","short","selectable","record_temperature","exterior"],DisabledSlots:4144959,Rotation:[180f],CustomNameVisible:0b}


## Cameras
summon minecraft:armor_stand 710 34 809 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c1"],DisabledSlots:4144959,Rotation:[-135.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 693 34 845 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c2"],DisabledSlots:4144959,Rotation:[-125.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 719 34 823 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c3"],DisabledSlots:4144959,Rotation:[73.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 723 34 829 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c4"],DisabledSlots:4144959,Rotation:[-12.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 737 34 808 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c5"],DisabledSlots:4144959,Rotation:[-140.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 763 34 832 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera","c6"],DisabledSlots:4144959,Rotation:[130.00f,18.00f],Pose:{Head:[15f,0f,0f]}}

summon minecraft:armor_stand 710 34 810 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera1_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[-135.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 693 34 846 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera2_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[-125.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 719 34 822 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera3_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[73.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 721 34 830 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera4_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[-25.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 736 34 808 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera5_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[-140.00f,18.00f],Pose:{Head:[15f,0f,0f]}}
summon minecraft:armor_stand 764 34 831 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_model","camera6_model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"CCTV"}}],Rotation:[130.00f,18.00f],Pose:{Head:[15f,0f,0f]}}

summon minecraft:armor_stand 689.0 31 814 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["camera_marker"],DisabledSlots:4144959,Rotation:[0f]}


## SKIP
summon minecraft:armor_stand 0 64 0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["SKIP_detect","SKIP"],DisabledSlots:4144959,CustomName:'{"text":"SKIP"}',CustomNameVisible:0b}


## Vent-markers
summon minecraft:armor_stand 686 31 806 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v1"],DisabledSlots:4144959,Rotation:[-60f]}
summon minecraft:armor_stand 689 31 824 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v2"],DisabledSlots:4144959,Rotation:[50f]}
summon minecraft:armor_stand 699 31 820 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v3"],DisabledSlots:4144959,Rotation:[-47f]}
summon minecraft:armor_stand 706 31 803 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v4"],DisabledSlots:4144959,Rotation:[140f]}
summon minecraft:armor_stand 740 31 805 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v5"],DisabledSlots:4144959,Rotation:[130f]}
summon minecraft:armor_stand 711 31 831 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v6"],DisabledSlots:4144959,Rotation:[-53f]}
summon minecraft:armor_stand 734 31 814 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v7"],DisabledSlots:4144959,Rotation:[115f]}
summon minecraft:armor_stand 721 31 832 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v8"],DisabledSlots:4144959,Rotation:[-110f]}
summon minecraft:armor_stand 726 31 846 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v9"],DisabledSlots:4144959,Rotation:[130f]}
summon minecraft:armor_stand 730 31 848 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v10"],DisabledSlots:4144959,Rotation:[-160f]}
summon minecraft:armor_stand 752 31 814 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v11"],DisabledSlots:4144959,Rotation:[-50f]}
summon minecraft:armor_stand 762 31 809 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["vent","v12"],DisabledSlots:4144959,Rotation:[-118f]}


## Faking
scoreboard objectives add faked dummy
scoreboard objectives add being_faked dummy
scoreboard players set @e[tag=task] faked 0
scoreboard players set @e[tag=task] being_faked 0


## Lights
setblock 704 32 811 lever[face=wall,facing=south,powered=true]
setblock 702 32 814 lever[face=wall,facing=south,powered=true]
setblock 702 32 817 lever[face=wall,facing=south,powered=true]
setblock 707 32 814 lever[face=wall,facing=south,powered=true]
setblock 707 32 817 lever[face=wall,facing=south,powered=true]

setblock 705 32 810 redstone_lamp[lit=true]
setblock 703 32 813 redstone_lamp[lit=true]
setblock 706 32 813 redstone_lamp[lit=true]
setblock 703 32 816 redstone_lamp[lit=true]
setblock 706 32 816 redstone_lamp[lit=true]


## Doors
scoreboard objectives add location dummy
scoreboard players set @a location 0
scoreboard objectives add close_door dummy
summon minecraft:armor_stand 709 31 806 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 709 31 807 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 695 31 818 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 694 31 818 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 699 31 810 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door3","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 700 31 810 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door3","electrical"],DisabledSlots:4144959}
summon minecraft:armor_stand 694 31 829 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","o2"],DisabledSlots:4144959}
summon minecraft:armor_stand 695 31 829 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","o2"],DisabledSlots:4144959}
summon minecraft:armor_stand 694 31 840 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","o2"],DisabledSlots:4144959}
summon minecraft:armor_stand 695 31 840 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","o2"],DisabledSlots:4144959}
summon minecraft:armor_stand 696 31 840 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","o2"],DisabledSlots:4144959}
summon minecraft:armor_stand 707 31 833 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","communications"],DisabledSlots:4144959}
summon minecraft:armor_stand 708 31 833 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","communications"],DisabledSlots:4144959}
summon minecraft:armor_stand 709 31 833 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","communications"],DisabledSlots:4144959}
summon minecraft:armor_stand 715 31 835 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","weapons"],DisabledSlots:4144959}
summon minecraft:armor_stand 714 31 835 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","weapons"],DisabledSlots:4144959}
summon minecraft:armor_stand 713 31 835 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","weapons"],DisabledSlots:4144959}
summon minecraft:armor_stand 724 31 810 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","storage"],DisabledSlots:4144959}
summon minecraft:armor_stand 724 31 811 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","storage"],DisabledSlots:4144959}
summon minecraft:armor_stand 724 31 812 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","storage"],DisabledSlots:4144959}
summon minecraft:armor_stand 724 31 839 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","office"],DisabledSlots:4144959}
summon minecraft:armor_stand 724 31 840 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","office"],DisabledSlots:4144959}
summon minecraft:armor_stand 752 31 827 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","office"],DisabledSlots:4144959}
summon minecraft:armor_stand 752 31 826 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","office"],DisabledSlots:4144959}
summon minecraft:armor_stand 752 31 825 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","office"],DisabledSlots:4144959}
summon minecraft:armor_stand 742 31 807 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 742 31 808 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 742 31 809 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door1","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 745 31 805 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 746 31 805 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 747 31 805 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["door","door2","laboratory"],DisabledSlots:4144959}


scoreboard players set @e[tag=door] close_door 0

## Decon
scoreboard objectives add decon dummy
scoreboard players set p1 decon 0
scoreboard players set p2 decon 0
scoreboard players set p3 decon 0
scoreboard players set p4 decon 0

## Decontamination doors
summon minecraft:armor_stand 775 31 808 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 775 31 809 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 777 31 812 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2","laboratory"],DisabledSlots:4144959}
summon minecraft:armor_stand 778 31 812 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2","laboratory"],DisabledSlots:4144959}

summon minecraft:armor_stand 741 31 842 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1","specimen_room"],DisabledSlots:4144959}
summon minecraft:armor_stand 740 31 842 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door1","specimen_room"],DisabledSlots:4144959}
summon minecraft:armor_stand 744 31 845 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2","specimen_room"],DisabledSlots:4144959}
summon minecraft:armor_stand 744 31 844 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["decon_door","door2","specimen_room"],DisabledSlots:4144959}

execute as @e[tag=decon_door] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block


## Admin map
summon minecraft:armor_stand 740 32 836.8 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","map_polus"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:35}}]}

## Sabotage alerts
summon minecraft:armor_stand 692 34 794.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","reactor_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[0f]}
summon minecraft:armor_stand 740 34 794.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","reactor_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[0f]}
summon minecraft:armor_stand 715.0 32 821 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","comms_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[90f]}
summon minecraft:armor_stand 701 33 811.0 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["alert","lights_alert"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:32}}],Rotation:[0f]}

team join alert @e[tag=alert]

## Dropship spawn
summon minecraft:armor_stand 725 34 782 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn0"],DisabledSlots:4144959}
summon minecraft:armor_stand 720 34 782 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn2"],DisabledSlots:4144959}
summon minecraft:armor_stand 726 34 782 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn4"],DisabledSlots:4144959}
summon minecraft:armor_stand 719 34 782 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn6"],DisabledSlots:4144959}
summon minecraft:armor_stand 727 34 783 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn8"],DisabledSlots:4144959}
summon minecraft:armor_stand 718 34 783 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn1"],DisabledSlots:4144959}
summon minecraft:armor_stand 727 34 784 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn3"],DisabledSlots:4144959}
summon minecraft:armor_stand 718 34 784 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn5"],DisabledSlots:4144959}
summon minecraft:armor_stand 727 34 785 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn7"],DisabledSlots:4144959}
summon minecraft:armor_stand 718 34 785 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["dropship_spawn","spawn9"],DisabledSlots:4144959}

## Office spawn
summon minecraft:armor_stand 729 31 827 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn0"],DisabledSlots:4144959}
summon minecraft:armor_stand 729 31 823 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn2"],DisabledSlots:4144959}
summon minecraft:armor_stand 732 31 826 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn4"],DisabledSlots:4144959}
summon minecraft:armor_stand 726 31 824 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn6"],DisabledSlots:4144959}
summon minecraft:armor_stand 728 31 827 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn8"],DisabledSlots:4144959}
summon minecraft:armor_stand 730 31 823 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn1"],DisabledSlots:4144959}
summon minecraft:armor_stand 730 31 827 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn3"],DisabledSlots:4144959}
summon minecraft:armor_stand 728 31 823 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn5"],DisabledSlots:4144959}
summon minecraft:armor_stand 726 31 826 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn7"],DisabledSlots:4144959}
summon minecraft:armor_stand 732 31 824 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["office_spawn","spawn9"],DisabledSlots:4144959}
execute as @e[tag=office_spawn] at @s facing 729 31 825 run tp @s ~ ~ ~ ~ ~


## Deco
summon minecraft:armor_stand 766 32 796 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","telescope"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:36}}],Rotation:[155f]}
summon minecraft:armor_stand 766 32 796 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","telescope_feet"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:37}}]}
summon minecraft:armor_stand 740 33 834 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","dvd_screen"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:38}}],Rotation:[270f]}
summon minecraft:armor_stand 719 31 812 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
summon minecraft:armor_stand 703 31 823 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
summon minecraft:armor_stand 699 31 847 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
summon minecraft:armor_stand 720 31 845 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
summon minecraft:armor_stand 738 31 803 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
summon minecraft:armor_stand 753 31 817 {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model","node"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:39}}],Rotation:[0f]}
execute as @e[tag=node] at @s run setblock ~ ~ ~ barrier
execute as @e[tag=node] at @s run setblock ~ ~1 ~ barrier




