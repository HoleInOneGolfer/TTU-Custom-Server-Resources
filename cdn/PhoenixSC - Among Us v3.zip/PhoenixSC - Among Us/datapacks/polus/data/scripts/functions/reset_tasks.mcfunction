kill @e[type=item]

## Dropship
function scripts:reset_tasks/dropship/chart
function scripts:reset_tasks/dropship/insert_keys

## Security
function scripts:reset_tasks/security/fix_wiring
function scripts:reset_tasks/security/upload_data

## O2
function scripts:reset_tasks/o2/fix_wiring
function scripts:reset_tasks/o2/upload_data
function scripts:reset_tasks/o2/monitor_tree
function scripts:reset_tasks/o2/fill_canisters
function scripts:reset_tasks/o2/empty_garbage

## Boiler Room
function scripts:reset_tasks/boiler_room/refill_water
function scripts:reset_tasks/boiler_room/open_waterways1
function scripts:reset_tasks/boiler_room/open_waterways2

## Communications
function scripts:reset_tasks/communications/reboot_wifi
function scripts:reset_tasks/communications/upload_data

## Weapons
function scripts:reset_tasks/weapons/upload_data
function scripts:reset_tasks/weapons/clear_asteroids

## Storage
function scripts:reset_tasks/storage/fuel1
function scripts:reset_tasks/storage/fuel2

## Office
function scripts:reset_tasks/office/refill_water
function scripts:reset_tasks/office/fix_wiring
function scripts:reset_tasks/office/swipe_card
function scripts:reset_tasks/office/scan_boarding
function scripts:reset_tasks/office/upload_data

## Laboratory
function scripts:reset_tasks/laboratory/repair_drill
function scripts:reset_tasks/laboratory/fix_weather
function scripts:reset_tasks/laboratory/record_temperature
function scripts:reset_tasks/laboratory/align_telescope
function scripts:reset_tasks/laboratory/inspect_sample
function scripts:reset_tasks/laboratory/fix_wiring_a
function scripts:reset_tasks/laboratory/fix_wiring_b
function scripts:reset_tasks/laboratory/fix_wiring_c
function scripts:reset_tasks/laboratory/submit_scan

## Specimen Room
function scripts:reset_tasks/specimen_room/upload_data
function scripts:reset_tasks/specimen_room/store_artifacts
function scripts:reset_tasks/specimen_room/start_reactor
function scripts:reset_tasks/specimen_room/unlock_manifolds

## Exterior
function scripts:reset_tasks/exterior/fuel1
function scripts:reset_tasks/exterior/fuel2
function scripts:reset_tasks/exterior/fix_weather1
function scripts:reset_tasks/exterior/fix_weather2
function scripts:reset_tasks/exterior/fix_weather3
function scripts:reset_tasks/exterior/fix_weather4
function scripts:reset_tasks/exterior/open_waterways1
function scripts:reset_tasks/exterior/open_waterways2
function scripts:reset_tasks/exterior/fix_weather5
function scripts:reset_tasks/exterior/fix_weather6
function scripts:reset_tasks/exterior/record_temperature


## SABOTAGE MISSIONS TO BE DONE IN-GAME

