fill 826 8 786 826 8 784 lever[face=wall,facing=east,powered=false]
fill 832 8 786 832 8 784 lever[face=wall,facing=west,powered=false]
fill 831 9 784 827 9 784 lever[face=ceiling,facing=north,powered=false]
fill 827 6 784 831 6 786 air
fill 826 9 783 832 6 787 air replace water