scoreboard players reset reboot_wifi
setblock 707 32 822 lever[face=wall,facing=south,powered=false]