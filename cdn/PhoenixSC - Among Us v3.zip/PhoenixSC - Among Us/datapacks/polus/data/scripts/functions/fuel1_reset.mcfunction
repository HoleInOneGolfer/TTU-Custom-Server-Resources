replaceitem entity @a[x=836,y=6,z=777,dx=6,dy=3,dz=1] weapon water_bucket{CanPlaceOn:["minecraft:cauldron"]}
fill 838 7 773 840 7 775 air