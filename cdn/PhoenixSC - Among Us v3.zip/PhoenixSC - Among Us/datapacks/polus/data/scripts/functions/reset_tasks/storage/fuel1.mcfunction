clone 895 11 746 895 11 746 901 6 744
setblock 899 6 741 water
clear @a[x=896,y=6,z=744,dx=6,dy=3,dz=1]