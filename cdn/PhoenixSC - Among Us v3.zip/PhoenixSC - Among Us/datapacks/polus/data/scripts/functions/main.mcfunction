##### IMPORTS #####
#/summon minecraft:armor_stand ~ ~ ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["model"],DisabledSlots:4144959,ArmorItems:[{},{},{},{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:0}}]}
tp @a[tag=!spawned] -231 1 5
tag @a add spawned
#effect give @a night_vision 9999 0 true
effect give @a jump_boost 9999 128 true
effect give @a resistance 9999 128 true
effect give @a fire_resistance 9999 128 true
effect give @a instant_health 9999 128 true
effect give @a weakness 9999 128 true
effect give @a[team=playing] speed 2 0 true
scoreboard objectives add settings dummy {"text":"Custom Settings"}
function scripts:settings
setworldspawn -231 1 5
forceload add 0 0
forceload add 629 928 815 738
forceload add 825 727 908 799
execute as @e[type=item] run data merge entity @s {PickupDelay:0s}
execute as @e[type=item] at @s run tp @s @p
function scripts:inventory
function scripts:click
scoreboard objectives add var dummy
scoreboard players set ticks_per_sec var 20
#weather rain
scoreboard objectives add food food
effect give @a[scores={food=2..}] minecraft:hunger 1 127 true
effect give @a[scores={food=..3}] minecraft:saturation 1 1 true
#stopsound @a player minecraft:entity.player.big_fall
effect give @e[tag=seat_pig] invisibility 9999 0 true
function scripts:off_seat
execute as @a at @s if block ~ ~ ~ iron_trapdoor[open=false] run function scripts:vent_failsafe


##### MAIN #####
## Game tracking
function scripts:game_track

## Reveal impostors
title @a[tag=impostor] actionbar ["",{"text":"Impostors: ","color":"white","bold":"true"},{"selector":"@a[tag=impostor]","color":"red"}]

## Locations
#execute at PhoenixSC run setblock ~ 0 ~ cyan_wool
execute as @a[team=playing] at @s unless block ~ ~-1 ~ netherite_block run function scripts:location
execute as @a[team=ghost] at @s unless block ~ ~-1 ~ netherite_block run function scripts:location

## Particles to reveal tasks
execute as @e[tag=incomplete,tag=!inspect_sample,tag=!reboot_wifi,scores={being_faked=0}] at @s if entity @a[distance=..4] run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0
execute unless score reboot_wifi reboot_wifi matches 0.. as @e[tag=incomplete,tag=communications,tag=reboot_wifi] at @s if entity @a[distance=..4] run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0
execute unless score inspect_sample inspect_sample matches 0.. as @e[tag=incomplete,tag=laboratory,tag=inspect_sample] at @s if entity @a[distance=..4] run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0

execute unless score inspect_sample inspect_sample matches 1.. run clone -277 77 -254 -277 77 -254 766 32 801
execute if score inspect_sample inspect_sample matches 1.. run clone -278 77 -254 -278 77 -254 766 32 801

execute unless score reboot_wifi reboot_wifi matches 1.. run setblock 707 30 822 redstone_lamp[lit=true]
execute if score reboot_wifi reboot_wifi matches 1.. run setblock 707 30 822 redstone_lamp[lit=false]

## TASKS
# O2, fill_canisters
setblock 899 6 730 minecraft:cauldron[level=3]

# O2, empty_garbage
execute if block 832 7 744 lever[powered=false] run fill 831 5 741 827 6 740 iron_block
execute if block 832 7 744 lever[powered=true] run fill 831 5 741 827 6 740 air

# Boiler Room, refill_water
setblock 839 7 741 minecraft:cauldron[level=3]

# Boiler Room, open_waterways1
execute if block 846 8 742 lever[powered=false] run setblock 846 7 742 air
execute if block 846 8 741 lever[powered=false] run setblock 846 7 741 air
execute if block 846 8 740 lever[powered=false] run setblock 846 7 740 air
execute if block 852 8 742 lever[powered=false] run setblock 852 7 742 air
execute if block 852 8 741 lever[powered=false] run setblock 852 7 741 air
execute if block 852 8 740 lever[powered=false] run setblock 852 7 740 air
execute if block 847 9 740 lever[powered=false] run setblock 847 9 741 air
execute if block 848 9 740 lever[powered=false] run setblock 848 9 741 air
execute if block 849 9 740 lever[powered=false] run setblock 849 9 741 air
execute if block 850 9 740 lever[powered=false] run setblock 850 9 741 air
execute if block 851 9 740 lever[powered=false] run setblock 851 9 741 air

execute if block 846 8 742 lever[powered=true] run setblock 846 7 742 water
execute if block 846 8 741 lever[powered=true] run setblock 846 7 741 water
execute if block 846 8 740 lever[powered=true] run setblock 846 7 740 water
execute if block 852 8 742 lever[powered=true] run setblock 852 7 742 water
execute if block 852 8 741 lever[powered=true] run setblock 852 7 741 water
execute if block 852 8 740 lever[powered=true] run setblock 852 7 740 water
execute if block 847 9 740 lever[powered=true] run setblock 847 9 741 water
execute if block 848 9 740 lever[powered=true] run setblock 848 9 741 water
execute if block 849 9 740 lever[powered=true] run setblock 849 9 741 water
execute if block 850 9 740 lever[powered=true] run setblock 850 9 741 water
execute if block 851 9 740 lever[powered=true] run setblock 851 9 741 water

# Boiler Room, open_waterways2
execute if block 856 8 742 lever[powered=false] run setblock 856 7 742 air
execute if block 856 8 741 lever[powered=false] run setblock 856 7 741 air
execute if block 856 8 740 lever[powered=false] run setblock 856 7 740 air
execute if block 852 8 742 lever[powered=false] run setblock 862 7 742 air
execute if block 852 8 741 lever[powered=false] run setblock 862 7 741 air
execute if block 852 8 740 lever[powered=false] run setblock 862 7 740 air
execute if block 857 9 740 lever[powered=false] run setblock 857 9 741 air
execute if block 858 9 740 lever[powered=false] run setblock 858 9 741 air
execute if block 859 9 740 lever[powered=false] run setblock 859 9 741 air
execute if block 860 9 740 lever[powered=false] run setblock 860 9 741 air
execute if block 861 9 740 lever[powered=false] run setblock 861 9 741 air

execute if block 856 8 742 lever[powered=true] run setblock 856 7 742 water
execute if block 856 8 741 lever[powered=true] run setblock 856 7 741 water
execute if block 856 8 740 lever[powered=true] run setblock 856 7 740 water
execute if block 862 8 742 lever[powered=true] run setblock 862 7 742 water
execute if block 862 8 741 lever[powered=true] run setblock 862 7 741 water
execute if block 862 8 740 lever[powered=true] run setblock 862 7 740 water
execute if block 857 9 740 lever[powered=true] run setblock 857 9 741 water
execute if block 858 9 740 lever[powered=true] run setblock 858 9 741 water
execute if block 859 9 740 lever[powered=true] run setblock 859 9 741 water
execute if block 860 9 740 lever[powered=true] run setblock 860 9 741 water
execute if block 861 9 740 lever[powered=true] run setblock 861 9 741 water

# Office, refill_water
setblock 839 7 752 minecraft:cauldron[level=3]

# Fuel bucket-miss check
execute if block 838 7 773 water run function scripts:fuel1_reset
execute if block 838 7 774 water run function scripts:fuel1_reset
execute if block 838 7 775 water run function scripts:fuel1_reset
execute if block 839 7 773 water run function scripts:fuel1_reset
execute if block 839 7 774 water run function scripts:fuel1_reset
execute if block 839 7 775 water run function scripts:fuel1_reset
execute if block 840 7 773 water run function scripts:fuel1_reset
execute if block 840 7 774 water run function scripts:fuel1_reset
execute if block 840 7 775 water run function scripts:fuel1_reset

execute if block 848 7 773 water run function scripts:fuel2_reset
execute if block 848 7 774 water run function scripts:fuel2_reset
execute if block 848 7 775 water run function scripts:fuel2_reset
execute if block 849 7 773 water run function scripts:fuel2_reset
execute if block 849 7 774 water run function scripts:fuel2_reset
execute if block 849 7 775 water run function scripts:fuel2_reset
execute if block 850 7 773 water run function scripts:fuel2_reset
execute if block 850 7 774 water run function scripts:fuel2_reset
execute if block 850 7 775 water run function scripts:fuel2_reset

# Exterior, open_waterways1
execute if block 896 8 775 lever[powered=false] run setblock 896 7 775 air
execute if block 896 8 774 lever[powered=false] run setblock 896 7 774 air
execute if block 896 8 773 lever[powered=false] run setblock 896 7 773 air
execute if block 902 8 775 lever[powered=false] run setblock 902 7 775 air
execute if block 902 8 774 lever[powered=false] run setblock 902 7 774 air
execute if block 902 8 773 lever[powered=false] run setblock 902 7 773 air
execute if block 897 9 773 lever[powered=false] run setblock 897 9 774 air
execute if block 898 9 773 lever[powered=false] run setblock 898 9 774 air
execute if block 899 9 773 lever[powered=false] run setblock 899 9 774 air
execute if block 900 9 773 lever[powered=false] run setblock 900 9 774 air
execute if block 901 9 773 lever[powered=false] run setblock 901 9 774 air

execute if block 896 8 775 lever[powered=true] run setblock 896 7 775 water
execute if block 896 8 774 lever[powered=true] run setblock 896 7 774 water
execute if block 896 8 773 lever[powered=true] run setblock 896 7 773 water
execute if block 902 8 775 lever[powered=true] run setblock 902 7 775 water
execute if block 902 8 774 lever[powered=true] run setblock 902 7 774 water
execute if block 902 8 773 lever[powered=true] run setblock 902 7 773 water
execute if block 897 9 773 lever[powered=true] run setblock 897 9 774 water
execute if block 898 9 773 lever[powered=true] run setblock 898 9 774 water
execute if block 899 9 773 lever[powered=true] run setblock 899 9 774 water
execute if block 900 9 773 lever[powered=true] run setblock 900 9 774 water
execute if block 901 9 773 lever[powered=true] run setblock 901 9 774 water

# Exterior, open_waterways2
execute if block 826 8 786 lever[powered=false] run setblock 826 7 786 air
execute if block 826 8 785 lever[powered=false] run setblock 826 7 785 air
execute if block 826 8 784 lever[powered=false] run setblock 826 7 784 air
execute if block 832 8 786 lever[powered=false] run setblock 832 7 786 air
execute if block 832 8 785 lever[powered=false] run setblock 832 7 785 air
execute if block 832 8 784 lever[powered=false] run setblock 832 7 784 air
execute if block 827 9 784 lever[powered=false] run setblock 827 9 785 air
execute if block 828 9 784 lever[powered=false] run setblock 828 9 785 air
execute if block 829 9 784 lever[powered=false] run setblock 829 9 785 air
execute if block 830 9 784 lever[powered=false] run setblock 830 9 785 air
execute if block 831 9 784 lever[powered=false] run setblock 831 9 785 air

execute if block 826 8 786 lever[powered=true] run setblock 826 7 786 water
execute if block 826 8 785 lever[powered=true] run setblock 826 7 785 water
execute if block 826 8 784 lever[powered=true] run setblock 826 7 784 water
execute if block 832 8 786 lever[powered=true] run setblock 832 7 786 water
execute if block 832 8 785 lever[powered=true] run setblock 832 7 785 water
execute if block 832 8 784 lever[powered=true] run setblock 832 7 784 water
execute if block 827 9 784 lever[powered=true] run setblock 827 9 785 water
execute if block 828 9 784 lever[powered=true] run setblock 828 9 785 water
execute if block 829 9 784 lever[powered=true] run setblock 829 9 785 water
execute if block 830 9 784 lever[powered=true] run setblock 830 9 785 water
execute if block 831 9 784 lever[powered=true] run setblock 831 9 785 water

# Communications, Reboot Wifi
execute unless entity @e[tag=in_meeting] if score reboot_wifi reboot_wifi matches 1.. if block 707 32 822 air run scoreboard players remove reboot_wifi reboot_wifi 1


# Laboratory
execute unless entity @e[tag=in_meeting] if score inspect_sample inspect_sample matches 1.. if block 768 32 799 air run scoreboard players remove inspect_sample inspect_sample 1
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=laboratory] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.0 0.0 0.0 1.0 10 force
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=laboratory] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run particle minecraft:reverse_portal ~ ~ ~ 0.0 0.0 0.0 1.0 10 force
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=laboratory] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run effect give @s nausea 3 10 true
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=laboratory] as @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] at @s run scoreboard players remove submit_scan submit_scan 1
execute if score submit_scan submit_scan matches 1.. at @e[tag=submit_scan,tag=laboratory] unless entity @p[distance=..2.0,limit=1,sort=nearest,tag=crewmate] run function scripts:submit_scan_check

## Check if task is occupied
function scripts:task_occupied
function scripts:connect_bodies

## Check task success
function scripts:task_success

## Camera TP
effect give @a[tag=surveil] invisibility 2 0 true
tp @a[tag=to_c1] @e[tag=c1,limit=1]
tp @a[tag=to_c2] @e[tag=c2,limit=1]
tp @a[tag=to_c3] @e[tag=c3,limit=1]
tp @a[tag=to_c4] @e[tag=c4,limit=1]
tp @a[tag=to_c5] @e[tag=c5,limit=1]
tp @a[tag=to_c6] @e[tag=c6,limit=1]

## Check if camera is occupied
function scripts:camera_occupied
execute as @e[tag=c1] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera1_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force
execute as @e[tag=c2] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera2_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force
execute as @e[tag=c3] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera3_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force
execute as @e[tag=c4] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera4_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force
execute as @e[tag=c5] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera5_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force
execute as @e[tag=c6] at @s if entity @p[distance=..0.1] run execute at @e[tag=camera6_model] run particle dust 1 0 0 0.25 ^0.34 ^1.5 ^-0.5 0.0 0.0 0.0 1.0 10 force

## Emergency Meeting cooldown
execute if score e_meeting_cd game_track matches 1.. run scoreboard players remove e_meeting_cd game_track 1

## Check meeting
execute if score e_meetings game_track < EmergencyMeetings settings if score e_meeting_cd game_track matches 0 if score o2 sabotage matches -1 if score reactor sabotage matches -1 if score comms sabotage matches -1 if score lights sabotage matches -1 unless entity @e[tag=report_body] run particle dust -1 1 0 0.5 729 32.5 825 0.0 0.0 0.0 1.0 10 force
execute if entity @e[tag=SKIP,tag=eject] run function scripts:meeting/result_skipped
execute if entity @e[tag=!SKIP,tag=eject] run function scripts:meeting/result_ejected

## Kill cooldown
execute as @a[tag=impostor,tag=!venting,tag=!surveil] if score @s kill_cd matches 1.. run scoreboard players remove @s kill_cd 1

## Clear blur
execute as @a[tag=crewmate] if score @s clear_blur matches 1.. run scoreboard players remove @s clear_blur 1
execute as @a[tag=crewmate] if score @s clear_blur matches 0 run replaceitem entity @s armor.head air

## Ghost movement
function scripts:ghost

## Vent TP
effect give @a[tag=venting] invisibility 2 0 true
function scripts:venting_system

## Fake mechanic
scoreboard players remove @e[scores={faked=1..}] faked 1
scoreboard players set @e[scores={faked=1}] being_faked 600
scoreboard players remove @e[scores={being_faked=1..}] being_faked 1

## Disable cameras if comms down
execute if score comms sabotage matches 0.. run title @a[tag=surveil] title {"text":""}
execute if score comms sabotage matches 0.. run title @a[tag=surveil] subtitle {"text":"Comms are down"}
execute if score comms sabotage matches 0.. run effect clear @a[tag=surveil] invisibility
execute if score comms sabotage matches 0.. run execute as @a[tag=surveil] run function scripts:exit_camera


## Sabotage cooldown
execute if score cd sabotage matches 1.. unless entity @a[tag=impostor,tag=venting] unless entity @a[tag=impostor,tag=surveil] run scoreboard players remove cd sabotage 1
execute if score cd_doors sabotage matches 1.. unless entity @a[tag=impostor,tag=venting] unless entity @a[tag=impostor,tag=surveil] run scoreboard players remove cd_doors sabotage 1

## Sabotage displays
execute if score o2 sabotage matches -1 if score reactor sabotage matches -1 run worldborder warning distance 0

execute if score reactor sabotage matches 0.. run function scripts:sabotage_display_reactor
execute if score reactor sabotage matches 0.. run execute store result bossbar minecraft:reactor value run scoreboard players get reactor sabotage
execute if score reactor sabotage matches -1 run bossbar set minecraft:reactor players
execute if score reactor sabotage matches 0..200 run worldborder warning distance 2000000000
function scripts:reactor_fix

execute if score reactor sabotage matches 0.. run execute as @e[tag=reactor_alert] run data merge entity @s {Glowing:1b}
execute if score reactor sabotage matches 0.. run execute as @e[tag=reactor_alert] run fill 740 36 792 740 38 792 minecraft:red_stained_glass
execute if score reactor sabotage matches 0.. run execute as @e[tag=reactor_alert] run fill 692 36 792 692 38 792 minecraft:red_stained_glass
execute if score lights sabotage matches 0.. run execute as @e[tag=lights_alert] run data merge entity @s {Glowing:1b}
execute if score comms sabotage matches 0.. run execute as @e[tag=comms_alert] run data merge entity @s {Glowing:1b}
execute if score reactor sabotage matches -1 run execute as @e[tag=reactor_alert] run data merge entity @s {Glowing:0b}
execute if score reactor sabotage matches -1 run execute as @e[tag=reactor_alert] run fill 740 36 792 740 38 792 minecraft:white_stained_glass
execute if score reactor sabotage matches -1 run execute as @e[tag=reactor_alert] run fill 692 36 792 692 38 792 minecraft:white_stained_glass
execute if score lights sabotage matches -1 run execute as @e[tag=lights_alert] run data merge entity @s {Glowing:0b}
execute if score comms sabotage matches -1 run execute as @e[tag=comms_alert] run data merge entity @s {Glowing:0b}

## Sabotage timers
execute if score reactor sabotage matches 1.. run scoreboard players remove reactor sabotage 1

scoreboard players add comms_anim sabotage 1
execute if score comms_anim sabotage matches 61.. run scoreboard players set comms_anim sabotage 0
execute if score comms_anim sabotage matches 1 run setblock 714 33 822 minecraft:polished_andesite
execute if score comms_anim sabotage matches 1 run setblock 714 33 827 minecraft:lime_wool
execute if score comms_anim sabotage matches 11 run setblock 714 33 827 minecraft:polished_andesite
execute if score comms_anim sabotage matches 11 run setblock 714 33 826 minecraft:lime_wool
execute if score comms_anim sabotage matches 21 run setblock 714 33 826 minecraft:polished_andesite
execute if score comms_anim sabotage matches 21 run setblock 714 33 825 minecraft:lime_wool
execute if score comms_anim sabotage matches 31 run setblock 714 33 825 minecraft:polished_andesite
execute if score comms_anim sabotage matches 31 run setblock 714 33 824 minecraft:lime_wool
execute if score comms_anim sabotage matches 41 run setblock 714 33 824 minecraft:polished_andesite
execute if score comms_anim sabotage matches 41 run setblock 714 33 823 minecraft:lime_wool
execute if score comms_anim sabotage matches 51 run setblock 714 33 823 minecraft:polished_andesite
execute if score comms_anim sabotage matches 51 run setblock 714 33 822 minecraft:lime_wool
execute if block 714 32 824 stone_button[face=floor,facing=west,powered=true] run function scripts:comms_fix

execute if score lights sabotage matches 1.. unless entity @e[tag=in_meeting] run effect give @a[tag=crewmate,tag=!ghost,tag=!surveil] blindness 2 0 true
effect clear @a[tag=surveil] blindness
function scripts:lights_fix

execute as @e[tag=door] if score @s close_door matches 1.. at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute as @e[tag=door] if score @s close_door matches 0 at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block

execute as @e[tag=door] if score @s close_door matches 199 at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5

## Check if game ends
execute if score o2 sabotage matches 0 run function scripts:game_check
execute if score reactor sabotage matches 0 run function scripts:game_check
execute if entity @e[tag=task] unless entity @e[tag=incomplete] run function scripts:crewmate_win

## Sprite in admin map
function scripts:sprites_map


## Fail-safe if no tasks left but bar is not full?

## Vote UI
function scripts:vote_confirm
execute if entity @a[tag=in_meeting] unless entity @a[scores={vote_id=-1}] run function scripts:vote_count

## Vote timer
execute if score timer vote_timer matches 1.. run scoreboard players remove timer vote_timer 1
execute store result bossbar minecraft:vote_timer value run scoreboard players get timer vote_timer
execute if score timer vote_timer matches 0 run function scripts:voting_runout

execute if score timer vote_timer matches 140 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1
execute if score timer vote_timer matches 120 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.05
execute if score timer vote_timer matches 100 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.10
execute if score timer vote_timer matches 80 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.15
execute if score timer vote_timer matches 60 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.20
execute if score timer vote_timer matches 40 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.25
execute if score timer vote_timer matches 20 run execute as @a at @s run playsound vote_timer master @s ~ ~ ~ 1 1.30

## Vote particle
execute as @a[tag=!ghost,scores={vote_id=11}] at @s run particle minecraft:dust 0 1 1 1 ~ ~2.55 ~ 0.0 0.02 0.0 1.0 0 force



## Environment
particle minecraft:dripping_obsidian_tear 731 60 823 20 0 15 0 4 force
particle minecraft:falling_dust snow 731 60 823 20 0 15 0 10 force
particle minecraft:falling_dust snow 731 40 823 20 0 15 0 10 force
particle minecraft:soul_fire_flame 705 35 814 2 0.3 2 0 1 force
particle minecraft:lava 766 25 822 7 0 3 0 1 force

#execute as @e[tag=task] at @s run particle minecraft:end_rod ~ ~1.5 ~ 0.0 0.0 0.0 1.0 0 force

## Decon
execute if score p1 decon matches 1.. run scoreboard players remove p1 decon 1
execute if score p2 decon matches 1.. run scoreboard players remove p2 decon 1
execute if score p3 decon matches 1.. run scoreboard players remove p3 decon 1
execute if score p4 decon matches 1.. run scoreboard players remove p4 decon 1

# p1
execute if score p1 decon matches 179 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p1 decon matches 179 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 120 run execute as @e[tag=door1] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p1 decon matches 120 run execute as @e[tag=door1] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 80..120 run particle cloud 779 31 809 0.0 0.0 0.0 1.0 10 force
execute if score p1 decon matches 120 positioned 779 30 811 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p1 decon matches 60 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p1 decon matches 60 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p1 decon matches 1 run execute as @e[tag=door2] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p1 decon matches 1 run execute as @e[tag=door2] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5

# p2
execute if score p2 decon matches 179 run execute as @e[tag=door2,tag=laboratory] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p2 decon matches 179 run execute as @e[tag=door2,tag=laboratory] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 120 run execute as @e[tag=door2,tag=laboratory] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p2 decon matches 120 run execute as @e[tag=door2,tag=laboratory] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 80..120 run particle cloud 779 31 809 0.0 0.0 0.0 1.0 10 force
execute if score p2 decon matches 120 positioned 779 30 811 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p2 decon matches 60 run execute as @e[tag=door1,tag=laboratory] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p2 decon matches 60 run execute as @e[tag=door1,tag=laboratory] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p2 decon matches 1 run execute as @e[tag=door1,tag=laboratory] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p2 decon matches 1 run execute as @e[tag=door1,tag=laboratory] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5

# p3
execute if score p3 decon matches 179 run execute as @e[tag=door1,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p3 decon matches 179 run execute as @e[tag=door1,tag=specimen_room] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p3 decon matches 120 run execute as @e[tag=door1,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p3 decon matches 120 run execute as @e[tag=door1,tag=specimen_room] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p3 decon matches 80..120 run particle cloud 740 31 846 0.0 0.0 0.0 1.0 10 force
execute if score p3 decon matches 120 positioned 740 31 846 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p3 decon matches 60 run execute as @e[tag=door2,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p3 decon matches 60 run execute as @e[tag=door2,tag=specimen_room] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p3 decon matches 1 run execute as @e[tag=door2,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p3 decon matches 1 run execute as @e[tag=door2,tag=specimen_room] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5

# p4
execute if score p4 decon matches 179 run execute as @e[tag=door2,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p4 decon matches 179 run execute as @e[tag=door2,tag=specimen_room] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p4 decon matches 120 run execute as @e[tag=door2,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p4 decon matches 120 run execute as @e[tag=door2,tag=specimen_room] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if score p4 decon matches 80..120 run particle cloud 740 31 846 0.0 0.0 0.0 1.0 10 force
execute if score p4 decon matches 120 positioned 740 31 846 run playsound minecraft:block.lava.extinguish master @a ~ ~ ~ 1 0.5
execute if score p4 decon matches 60 run execute as @e[tag=door1,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if score p4 decon matches 60 run execute as @e[tag=door1,tag=specimen_room] at @s run playsound minecraft:block.piston.extend master @a ~ ~ ~ 0.2 0.5
execute if score p4 decon matches 1 run execute as @e[tag=door1,tag=specimen_room] at @s run fill ~ ~ ~ ~ ~2 ~ iron_block replace air
execute if score p4 decon matches 1 run execute as @e[tag=door1,tag=specimen_room] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5


## Doors fix
execute if block 710 32 808 stone_button[powered=true] if block 710 32 805 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 710 32 808 stone_button[powered=true] if block 710 32 805 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 710 32 808 stone_button[powered=true] if block 710 32 805 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 708 32 805 stone_button[powered=true] if block 708 32 808 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 708 32 805 stone_button[powered=true] if block 708 32 808 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 708 32 805 stone_button[powered=true] if block 708 32 808 stone_button[powered=true] as @e[tag=door1,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 701 32 808 stone_button[powered=true] if block 698 32 808 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 701 32 808 stone_button[powered=true] if block 698 32 808 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 701 32 808 stone_button[powered=true] if block 698 32 808 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 701 32 811 stone_button[powered=true] if block 698 32 811 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 701 32 811 stone_button[powered=true] if block 698 32 811 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 701 32 811 stone_button[powered=true] if block 698 32 811 stone_button[powered=true] as @e[tag=door3,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 696 32 817 stone_button[powered=true] if block 693 32 817 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 696 32 817 stone_button[powered=true] if block 693 32 817 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 696 32 817 stone_button[powered=true] if block 693 32 817 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 696 32 819 stone_button[powered=true] if block 693 32 819 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 696 32 819 stone_button[powered=true] if block 693 32 819 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 696 32 819 stone_button[powered=true] if block 693 32 819 stone_button[powered=true] as @e[tag=door2,tag=electrical,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 696 32 828 stone_button[powered=true] if block 693 32 828 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 696 32 828 stone_button[powered=true] if block 693 32 828 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 696 32 828 stone_button[powered=true] if block 693 32 828 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 693 32 830 stone_button[powered=true] if block 696 32 830 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 693 32 830 stone_button[powered=true] if block 696 32 830 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 693 32 830 stone_button[powered=true] if block 696 32 830 stone_button[powered=true] as @e[tag=door1,tag=o2,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 697 32 839 stone_button[powered=true] if block 693 32 839 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 697 32 839 stone_button[powered=true] if block 693 32 839 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 697 32 839 stone_button[powered=true] if block 693 32 839 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 697 32 841 stone_button[powered=true] if block 693 32 841 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 697 32 841 stone_button[powered=true] if block 693 32 841 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 697 32 841 stone_button[powered=true] if block 693 32 841 stone_button[powered=true] as @e[tag=door2,tag=o2,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 706 32 834 stone_button[powered=true] if block 710 32 834 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 706 32 834 stone_button[powered=true] if block 710 32 834 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 706 32 834 stone_button[powered=true] if block 710 32 834 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 709 34 832 stone_button[powered=true] if block 707 34 832 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 709 34 832 stone_button[powered=true] if block 707 34 832 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 709 34 832 stone_button[powered=true] if block 707 34 832 stone_button[powered=true] as @e[tag=door1,tag=communications,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 716 32 834 stone_button[powered=true] if block 712 32 834 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 716 32 834 stone_button[powered=true] if block 712 32 834 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 716 32 834 stone_button[powered=true] if block 712 32 834 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 713 34 836 stone_button[powered=true] if block 715 34 836 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 713 34 836 stone_button[powered=true] if block 715 34 836 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 713 34 836 stone_button[powered=true] if block 715 34 836 stone_button[powered=true] as @e[tag=door1,tag=weapons,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 723 32 809 stone_button[powered=true] if block 723 32 813 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 723 32 809 stone_button[powered=true] if block 723 32 813 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 723 32 809 stone_button[powered=true] if block 723 32 813 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 725 34 812 stone_button[powered=true] if block 725 34 810 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 725 34 812 stone_button[powered=true] if block 725 34 810 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 725 34 812 stone_button[powered=true] if block 725 34 810 stone_button[powered=true] as @e[tag=door1,tag=storage,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 723 32 838 stone_button[powered=true] if block 723 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 723 32 838 stone_button[powered=true] if block 723 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 723 32 838 stone_button[powered=true] if block 723 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 725 32 838 stone_button[powered=true] if block 725 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 725 32 838 stone_button[powered=true] if block 725 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 725 32 838 stone_button[powered=true] if block 725 32 841 stone_button[powered=true] as @e[tag=door1,tag=office,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0


execute if block 751 32 824 stone_button[powered=true] if block 751 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 751 32 824 stone_button[powered=true] if block 751 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 751 32 824 stone_button[powered=true] if block 751 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 753 32 824 stone_button[powered=true] if block 753 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 753 32 824 stone_button[powered=true] if block 753 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 753 32 824 stone_button[powered=true] if block 753 32 828 stone_button[powered=true] as @e[tag=door2,tag=office,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0



execute if block 741 32 806 stone_button[powered=true] if block 741 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 741 32 806 stone_button[powered=true] if block 741 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 741 32 806 stone_button[powered=true] if block 741 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 743 32 806 stone_button[powered=true] if block 743 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 743 32 806 stone_button[powered=true] if block 743 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 743 32 806 stone_button[powered=true] if block 743 32 810 stone_button[powered=true] as @e[tag=door1,tag=laboratory,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 744 32 806 stone_button[powered=true] if block 748 32 806 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 744 32 806 stone_button[powered=true] if block 748 32 806 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 744 32 806 stone_button[powered=true] if block 748 32 806 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0

execute if block 748 32 804 stone_button[powered=true] if block 744 32 804 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 0.2 0.5
execute if block 748 32 804 stone_button[powered=true] if block 744 32 804 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run fill ~ ~ ~ ~ ~2 ~ air replace iron_block
execute if block 748 32 804 stone_button[powered=true] if block 744 32 804 stone_button[powered=true] as @e[tag=door2,tag=laboratory,scores={close_door=1..}] at @s run scoreboard players set @s close_door 0
