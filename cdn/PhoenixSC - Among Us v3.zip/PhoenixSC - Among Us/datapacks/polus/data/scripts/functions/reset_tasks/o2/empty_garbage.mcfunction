setblock 832 7 744 lever[powered=false,face=wall,facing=west]
fill 831 7 741 827 7 740 gravel
setblock 828 8 740 gravel
fill 830 8 741 830 8 740 gravel
setblock 830 9 740 gravel

execute if score stage game_track matches 0 run function scripts:randomisers/5

execute if score var1 var matches 1 run fill 827 7 740 831 9 741 sand replace gravel
execute if score var1 var matches 2 run fill 827 7 740 831 9 741 red_sand replace gravel
execute if score var1 var matches 3 run fill 827 7 740 831 9 741 anvil replace gravel
execute if score var1 var matches 4 run fill 827 7 740 831 9 741 light_blue_concrete_powder replace gravel