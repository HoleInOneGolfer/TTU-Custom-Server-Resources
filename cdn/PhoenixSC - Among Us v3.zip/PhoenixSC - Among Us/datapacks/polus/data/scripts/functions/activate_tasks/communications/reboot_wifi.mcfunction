scoreboard objectives add reboot_wifi dummy
execute as @a at @s run playsound minecraft:block.conduit.activate master @s ~ ~ ~ 9999 2.0

## Crewmate/Impostor
scoreboard players set reboot_wifi reboot_wifi 900
setblock 707 32 822 air