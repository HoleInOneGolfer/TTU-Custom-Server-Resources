execute as @a[x=846,y=6,z=744,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=846,y=6,z=744,dx=6,dy=3,dz=1] @e[tag=boiler_room,tag=open_waterways1,limit=1]

execute as @e[tag=boiler_room,tag=open_waterways1,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/boiler_room/open_waterways1

execute as @e[tag=exterior,tag=open_waterways1,limit=1] run function scripts:increment_task