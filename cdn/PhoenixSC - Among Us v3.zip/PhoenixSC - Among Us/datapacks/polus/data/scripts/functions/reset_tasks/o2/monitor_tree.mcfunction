fill 886 9 732 890 9 732 lever[face=wall,facing=south,powered=false]
fill 886 7 732 887 7 732 lever[face=floor,facing=north,powered=false]


fill 886 8 731 892 7 731 redstone_lamp[lit=false]