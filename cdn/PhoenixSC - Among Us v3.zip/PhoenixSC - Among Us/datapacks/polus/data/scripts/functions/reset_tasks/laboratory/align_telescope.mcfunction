fill 836 9 765 842 7 765 coal_block
fill 836 9 764 842 7 764 minecraft:black_concrete
clone 842 11 767 842 11 767 842 6 767

execute if score stage game_track matches 0 run function scripts:randomisers/7
execute if score var2 var matches 0 run setblock 837 9 764 minecraft:gilded_blackstone
execute if score var2 var matches 1 run setblock 839 9 764 minecraft:gilded_blackstone
execute if score var2 var matches 2 run setblock 837 8 764 minecraft:gilded_blackstone
execute if score var2 var matches 3 run setblock 839 8 764 minecraft:gilded_blackstone
execute if score var2 var matches 4 run setblock 839 7 764 minecraft:gilded_blackstone
execute if score var2 var matches 5 run setblock 842 7 764 minecraft:gilded_blackstone
execute if score var2 var matches 6 run setblock 836 7 764 minecraft:gilded_blackstone

execute if score var2 var matches 0 run setblock 839 25 764 white_wool
execute if score var2 var matches 1 run setblock 839 25 764 orange_wool
execute if score var2 var matches 2 run setblock 839 25 764 magenta_wool
execute if score var2 var matches 3 run setblock 839 25 764 light_blue_wool
execute if score var2 var matches 4 run setblock 839 25 764 yellow_wool
execute if score var2 var matches 5 run setblock 839 25 764 lime_wool
execute if score var2 var matches 6 run setblock 839 25 764 pink_wool

clear @a[x=836,y=6,z=766,dx=6,dy=3,dz=1]