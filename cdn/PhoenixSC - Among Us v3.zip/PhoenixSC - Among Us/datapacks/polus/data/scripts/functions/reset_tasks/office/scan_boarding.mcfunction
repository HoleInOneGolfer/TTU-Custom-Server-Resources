setblock 871 6 755 air
setblock 871 6 755 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:scute",Count:1b}]}

setblock 868 7 753 minecraft:air
setblock 868 7 753 minecraft:hopper

clear @a[x=866,y=6,z=755,dx=6,dy=3,dz=1]