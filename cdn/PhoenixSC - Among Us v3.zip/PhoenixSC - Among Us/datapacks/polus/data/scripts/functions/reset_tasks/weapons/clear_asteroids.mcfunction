clone 892 11 743 886 13 740 886 7 740
setblock 892 6 745 air
setblock 892 6 745 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:netherite_pickaxe",Count:1b,tag:{CanDestroy:["minecraft:cobblestone"],Unbreakable:1b}}]}
clear @a[x=886,y=6,z=744,dx=6,dy=3,dz=1]