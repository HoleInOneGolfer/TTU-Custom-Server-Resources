scoreboard players reset inspect_sample
setblock 768 32 799 lever[face=wall,facing=west,powered=false]