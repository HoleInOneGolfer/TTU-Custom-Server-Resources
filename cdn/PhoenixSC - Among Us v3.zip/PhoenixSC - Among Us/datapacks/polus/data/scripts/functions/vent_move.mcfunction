scoreboard players add @s vent_number 1
execute as @s at @s run playsound minecraft:generic master @s ~ ~ ~ 9999

## Limits
execute as @s[tag=vent_system1] if score @s vent_number matches 4.. run scoreboard players set @s vent_number 1
execute as @s[tag=vent_system2] if score @s vent_number matches 6.. run scoreboard players set @s vent_number 4
execute as @s[tag=vent_system3] if score @s vent_number matches 9.. run scoreboard players set @s vent_number 6
execute as @s[tag=vent_system4] if score @s vent_number matches 13.. run scoreboard players set @s vent_number 9
