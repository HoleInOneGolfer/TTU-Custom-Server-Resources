setblock 861 6 755 air
setblock 861 6 755 chest[facing=west]{Items:[{Slot:13b,id:"minecraft:paper",Count:1b}]}

setblock 858 7 753 minecraft:air
setblock 858 7 753 minecraft:hopper

clear @a[x=856,y=6,z=755,dx=6,dy=3,dz=1]