setblock 888 9 753 cracked_stone_bricks
setblock 888 9 751 cracked_stone_bricks
setblock 890 9 753 cracked_stone_bricks
setblock 890 9 751 cracked_stone_bricks
setblock 888 7 753 cracked_stone_bricks
setblock 888 7 751 cracked_stone_bricks
setblock 890 7 753 cracked_stone_bricks
setblock 890 7 751 cracked_stone_bricks

clone 893 11 757 893 11 757 892 6 756
clear @a[x=886,y=6,z=755,dx=6,dy=3,dz=1]