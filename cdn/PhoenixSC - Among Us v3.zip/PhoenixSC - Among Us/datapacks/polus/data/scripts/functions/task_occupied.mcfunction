tag @e[tag=task,scores={faked=0}] remove occupied

# Dropship
execute if entity @a[x=826,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=dropship,tag=chart_course] add occupied
execute if entity @a[x=836,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=dropship,tag=insert_keys] add occupied

# Security
execute if entity @a[x=846,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=security,tag=fix_wiring] add occupied
execute if entity @a[x=856,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=security,tag=upload_data] add occupied

# O2
execute if entity @a[x=866,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=o2,tag=fix_wiring] add occupied
execute if entity @a[x=876,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=o2,tag=upload_data] add occupied
execute if entity @a[x=886,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=o2,tag=monitor_tree] add occupied
execute if entity @a[x=896,y=6,z=733,dx=6,dy=3,dz=1] run tag @e[tag=o2,tag=fill_canisters] add occupied
execute if entity @a[x=826,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=o2,tag=empty_garbage] add occupied

# Boiler Room
execute if entity @a[x=836,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=boiler_room,tag=refill_water] add occupied
execute if entity @a[x=846,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=boiler_room,tag=open_waterways1] add occupied
execute if entity @a[x=856,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=boiler_room,tag=open_waterways2] add occupied

# Communications
execute if entity @a[x=866,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=communications,tag=upload_data] add occupied

# Weapons
execute if entity @a[x=876,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=weapons,tag=upload_data] add occupied
execute if entity @a[x=886,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=weapons,tag=clear_asteroids] add occupied

# Storage
execute if entity @a[x=896,y=6,z=744,dx=6,dy=3,dz=1] run tag @e[tag=storage,tag=fuel1] add occupied
execute if entity @a[x=826,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=storage,tag=fuel2] add occupied

# Office
execute if entity @a[x=836,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=office,tag=refill_water] add occupied
execute if entity @a[x=846,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=office,tag=fix_wiring] add occupied
execute if entity @a[x=856,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=office,tag=swipe_card] add occupied
execute if entity @a[x=866,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=office,tag=scan_boarding] add occupied
execute if entity @a[x=876,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=office,tag=upload_data] add occupied

# Laboratory
execute if entity @a[x=886,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=repair_drill] add occupied
execute if entity @a[x=896,y=6,z=755,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=fix_weather] add occupied
execute if entity @a[x=826,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=record_temperature] add occupied
execute if entity @a[x=836,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=align_telescope] add occupied
execute if entity @a[x=846,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=fix_wiring_a] add occupied
execute if entity @a[x=856,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=fix_wiring_b] add occupied
execute if entity @a[x=866,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=laboratory,tag=fix_wiring_c] add occupied

# Specimen Room
execute if entity @a[x=876,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=specimen_room,tag=upload_data] add occupied
execute if entity @a[x=886,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=specimen_room,tag=store_artifacts] add occupied
execute if entity @a[x=896,y=6,z=766,dx=6,dy=3,dz=1] run tag @e[tag=specimen_room,tag=start_reactor] add occupied
execute if entity @a[x=826,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=specimen_room,tag=unlock_manifolds] add occupied

# Exterior
execute if entity @a[x=836,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fuel1] add occupied
execute if entity @a[x=846,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fuel2] add occupied
execute if entity @a[x=856,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather1] add occupied
execute if entity @a[x=866,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather2] add occupied
execute if entity @a[x=876,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather3] add occupied
execute if entity @a[x=886,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather4] add occupied
execute if entity @a[x=896,y=6,z=777,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=open_waterways1] add occupied
execute if entity @a[x=826,y=6,z=788,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=open_waterways2] add occupied
execute if entity @a[x=836,y=6,z=788,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather5] add occupied
execute if entity @a[x=846,y=6,z=788,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=fix_weather6] add occupied
execute if entity @a[x=856,y=6,z=788,dx=6,dy=3,dz=1] run tag @e[tag=exterior,tag=record_temperature] add occupied
