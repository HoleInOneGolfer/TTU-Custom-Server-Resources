fill 826 6 766 832 6 766 lever[face=wall,facing=south,powered=false]
fill 832 7 765 826 7 765 minecraft:redstone_lamp[lit=false]
fill 832 9 765 826 9 765 red_wool

execute if score stage game_track matches 0 run function scripts:randomisers/7
execute if score var2 var matches 0 run fill 826 9 765 826 9 765 yellow_wool
execute if score var2 var matches 1 run fill 827 9 765 826 9 765 yellow_wool
execute if score var2 var matches 2 run fill 828 9 765 826 9 765 yellow_wool
execute if score var2 var matches 3 run fill 829 9 765 826 9 765 yellow_wool
execute if score var2 var matches 4 run fill 830 9 765 826 9 765 yellow_wool
execute if score var2 var matches 5 run fill 831 9 765 826 9 765 yellow_wool
execute if score var2 var matches 6 run fill 832 9 765 826 9 765 yellow_wool

execute if score var2 var matches 0 run setblock 829 25 764 white_wool
execute if score var2 var matches 1 run setblock 829 25 764 orange_wool
execute if score var2 var matches 2 run setblock 829 25 764 magenta_wool
execute if score var2 var matches 3 run setblock 829 25 764 light_blue_wool
execute if score var2 var matches 4 run setblock 829 25 764 yellow_wool
execute if score var2 var matches 5 run setblock 829 25 764 lime_wool
execute if score var2 var matches 6 run setblock 829 25 764 pink_wool