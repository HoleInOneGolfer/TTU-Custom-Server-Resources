setblock 896 7 752 lever[face=wall,facing=south,powered=false]
setblock 897 7 754 lever[face=wall,facing=south,powered=false]
setblock 898 7 752 lever[face=wall,facing=south,powered=false]
setblock 900 7 754 lever[face=wall,facing=south,powered=false]
setblock 901 7 752 lever[face=wall,facing=south,powered=false]
setblock 902 7 754 lever[face=wall,facing=south,powered=false]

fill 896 8 751 902 8 753 redstone_lamp[lit=false] replace minecraft:redstone_lamp