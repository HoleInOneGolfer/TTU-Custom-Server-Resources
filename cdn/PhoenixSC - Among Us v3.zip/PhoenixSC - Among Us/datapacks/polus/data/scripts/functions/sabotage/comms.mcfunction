scoreboard players set comms sabotage 1
scoreboard players set cd sabotage 2000000
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Reactor","italic":"false"}'},HideFlags:63,CustomModelData:10}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Comms","italic":"false"}'},HideFlags:63,CustomModelData:11}
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Lights","italic":"false"}'},HideFlags:63,CustomModelData:12}
execute as @a at @s run playsound minecraft:comms_down master @s ~ ~ ~ 0.5

title @a title {"text":""}
title @a subtitle {"text":"Comms are down"}


