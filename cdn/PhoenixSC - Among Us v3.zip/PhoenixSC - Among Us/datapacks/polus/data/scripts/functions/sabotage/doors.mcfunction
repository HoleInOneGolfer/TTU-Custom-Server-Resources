scoreboard players set cd_doors sabotage 100
clear @a carrot_on_a_stick{display:{Name:'{"text":"Sabotage Doors","italic":"false"}'},HideFlags:63,CustomModelData:13}

function scripts:sabotage_doors

