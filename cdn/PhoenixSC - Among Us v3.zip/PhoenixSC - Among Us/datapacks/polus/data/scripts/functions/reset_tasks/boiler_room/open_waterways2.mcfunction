fill 856 8 742 856 8 740 lever[face=wall,facing=east,powered=false]
fill 862 8 740 862 8 742 lever[face=wall,facing=west,powered=false]
fill 861 9 740 857 9 740 lever[face=ceiling,facing=north,powered=false]
fill 857 6 742 861 6 740 air
fill 862 6 743 856 9 739 air replace water