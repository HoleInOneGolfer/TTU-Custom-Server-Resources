execute as @a at @s run playsound minecraft:block.conduit.deactivate master @s ~ ~ ~ 9999 1.5

execute as @e[tag=communications,tag=reboot_wifi,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/communications/reboot_wifi