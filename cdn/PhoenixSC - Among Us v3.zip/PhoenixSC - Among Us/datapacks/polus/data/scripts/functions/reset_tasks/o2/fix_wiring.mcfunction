fill 866 7 731 872 7 731 air
execute if score stage game_track matches 0 run function scripts:randomisers/5
execute if score var1 var matches 0 run clone 865 11 735 865 11 735 871 6 733
execute if score var1 var matches 1 run clone 866 11 735 866 11 735 871 6 733
execute if score var1 var matches 2 run clone 867 11 735 867 11 735 871 6 733
execute if score var1 var matches 3 run clone 868 11 735 868 11 735 871 6 733
execute if score var1 var matches 4 run clone 869 11 735 869 11 735 871 6 733
clear @a[x=866,y=6,z=733,dx=6,dy=3,dz=1]