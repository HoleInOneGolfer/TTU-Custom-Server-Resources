clone 895 11 746 895 11 746 831 6 755
setblock 829 6 752 water
clear @a[x=826,y=6,z=755,dx=6,dy=3,dz=1]