fill 848 6 773 850 6 775 cauldron[level=0]
clone 835 11 779 835 11 779 851 6 777
clear @a[x=846,y=6,z=777,dx=6,dy=3,dz=1]