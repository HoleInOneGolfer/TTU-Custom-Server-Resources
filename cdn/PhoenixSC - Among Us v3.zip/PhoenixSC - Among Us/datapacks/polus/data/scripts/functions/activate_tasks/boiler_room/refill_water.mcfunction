## Crewmate
execute if entity @s[tag=crewmate] run tp @s 839 6 745 180 5

## Impostor
execute if entity @s[tag=impostor] run function scripts:faked