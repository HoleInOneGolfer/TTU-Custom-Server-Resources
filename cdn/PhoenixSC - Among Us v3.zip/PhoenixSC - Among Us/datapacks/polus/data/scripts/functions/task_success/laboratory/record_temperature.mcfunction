execute as @a[x=826,y=6,z=766,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=826,y=6,z=766,dx=6,dy=3,dz=1] @e[tag=laboratory,tag=record_temperature,limit=1]

execute as @e[tag=laboratory,tag=record_temperature,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/record_temperature

