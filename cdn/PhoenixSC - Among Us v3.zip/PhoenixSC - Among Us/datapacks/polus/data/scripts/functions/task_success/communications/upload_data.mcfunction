execute as @a[x=866,y=6,z=744,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
tp @a[x=866,y=6,z=744,dx=6,dy=3,dz=1] @e[tag=communications,tag=upload_data,limit=1]

execute as @e[tag=communications,tag=upload_data,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/communications/upload_data

