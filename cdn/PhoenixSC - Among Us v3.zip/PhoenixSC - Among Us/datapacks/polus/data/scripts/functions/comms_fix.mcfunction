execute if block 714 33 824 minecraft:lime_wool if score comms sabotage matches 1.. run execute as @a at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
execute if block 714 33 824 minecraft:lime_wool if score comms sabotage matches 1.. run title @a title {"text":""}
execute if block 714 33 824 minecraft:lime_wool if score comms sabotage matches 1.. run title @a subtitle {"text":"Comms restored"}
execute if block 714 33 824 minecraft:lime_wool if score comms sabotage matches 1.. run scoreboard players set cd sabotage 340

execute if block 714 33 824 minecraft:lime_wool run scoreboard players set comms sabotage -1

setblock 714 32 824 stone_button[face=floor,facing=west,powered=false] 