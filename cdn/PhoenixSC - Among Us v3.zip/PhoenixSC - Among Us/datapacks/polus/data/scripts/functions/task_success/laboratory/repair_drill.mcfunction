execute as @a[x=886,y=6,z=755,dx=6,dy=3,dz=1] at @s run playsound minecraft:task_completed master @s ~ ~ ~ 9999
clear @a[x=886,y=6,z=755,dx=6,dy=3,dz=1] iron_pickaxe
clear @a[x=886,y=6,z=755,dx=6,dy=3,dz=1] stone_bricks
tp @a[x=886,y=6,z=755,dx=6,dy=3,dz=1] @e[tag=laboratory,tag=repair_drill,limit=1]

execute as @e[tag=laboratory,tag=repair_drill,limit=1] run function scripts:decrement_task
function scripts:reset_tasks/laboratory/repair_drill

