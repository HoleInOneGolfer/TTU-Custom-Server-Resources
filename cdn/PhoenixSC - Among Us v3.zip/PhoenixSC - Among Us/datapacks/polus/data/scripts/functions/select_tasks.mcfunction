##### IMPORTS #####
scoreboard objectives add increment_task dummy


##### MAIN #####
## Short
execute if score ShortTasks settings matches ..1 run execute as @e[tag=task,tag=selectable,tag=short,limit=1,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 2 run execute as @e[tag=task,tag=selectable,tag=short,limit=2,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 3 run execute as @e[tag=task,tag=selectable,tag=short,limit=3,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 4 run execute as @e[tag=task,tag=selectable,tag=short,limit=4,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 5 run execute as @e[tag=task,tag=selectable,tag=short,limit=5,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 6 run execute as @e[tag=task,tag=selectable,tag=short,limit=6,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 7 run execute as @e[tag=task,tag=selectable,tag=short,limit=7,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 8 run execute as @e[tag=task,tag=selectable,tag=short,limit=8,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 9 run execute as @e[tag=task,tag=selectable,tag=short,limit=9,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 10 run execute as @e[tag=task,tag=selectable,tag=short,limit=10,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 11 run execute as @e[tag=task,tag=selectable,tag=short,limit=11,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 12 run execute as @e[tag=task,tag=selectable,tag=short,limit=12,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 13 run execute as @e[tag=task,tag=selectable,tag=short,limit=13,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 14 run execute as @e[tag=task,tag=selectable,tag=short,limit=14,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 15 run execute as @e[tag=task,tag=selectable,tag=short,limit=15,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 16 run execute as @e[tag=task,tag=selectable,tag=short,limit=16,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 17 run execute as @e[tag=task,tag=selectable,tag=short,limit=17,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 18 run execute as @e[tag=task,tag=selectable,tag=short,limit=18,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 19 run execute as @e[tag=task,tag=selectable,tag=short,limit=19,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 20 run execute as @e[tag=task,tag=selectable,tag=short,limit=20,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 21 run execute as @e[tag=task,tag=selectable,tag=short,limit=21,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 22 run execute as @e[tag=task,tag=selectable,tag=short,limit=22,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 23 run execute as @e[tag=task,tag=selectable,tag=short,limit=23,sort=random] run function scripts:increment_task	
execute if score ShortTasks settings matches 24.. run execute as @e[tag=task,tag=selectable,tag=short,limit=24,sort=random] run function scripts:increment_task	

## Long
execute if score LongTasks settings matches ..1 run execute as @e[tag=task,tag=selectable,tag=long,limit=1,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 2 run execute as @e[tag=task,tag=selectable,tag=long,limit=2,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 3 run execute as @e[tag=task,tag=selectable,tag=long,limit=3,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 4 run execute as @e[tag=task,tag=selectable,tag=long,limit=4,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 5 run execute as @e[tag=task,tag=selectable,tag=long,limit=5,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 6 run execute as @e[tag=task,tag=selectable,tag=long,limit=6,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 7 run execute as @e[tag=task,tag=selectable,tag=long,limit=7,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 8 run execute as @e[tag=task,tag=selectable,tag=long,limit=8,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 9 run execute as @e[tag=task,tag=selectable,tag=long,limit=9,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 10 run execute as @e[tag=task,tag=selectable,tag=long,limit=10,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 11 run execute as @e[tag=task,tag=selectable,tag=long,limit=11,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 12 run execute as @e[tag=task,tag=selectable,tag=long,limit=12,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 13 run execute as @e[tag=task,tag=selectable,tag=long,limit=13,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 14 run execute as @e[tag=task,tag=selectable,tag=long,limit=14,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 15 run execute as @e[tag=task,tag=selectable,tag=long,limit=15,sort=random] run function scripts:increment_task
execute if score LongTasks settings matches 16.. run execute as @e[tag=task,tag=selectable,tag=long,limit=16,sort=random] run function scripts:increment_task